extends Area2D

var velocidad = 250


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x += velocidad * delta
	if position.x > 1200 or position.x < 80:
		velocidad = - velocidad
