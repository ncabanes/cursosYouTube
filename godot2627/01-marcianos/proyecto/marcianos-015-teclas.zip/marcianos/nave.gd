extends Area2D

var velocidad = 400
var escena_disparo

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	add_to_group("nave")
	escena_disparo = load("res://disparo.tscn")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("derecha"):
		position.x += velocidad * delta
	if Input.is_action_pressed("izquierda"):
		position.x -= velocidad * delta
	if Input.is_action_just_pressed("disparo"):
		var disparo = escena_disparo.instantiate()
		disparo.position = position
		get_parent().add_child(disparo)
		get_parent().reproducir_sonido_disparo()
