extends Area2D

var velocidad = 150
var escena_explosion

func _ready() -> void:
	escena_explosion = load("res://explosion.tscn")

func _process(delta: float) -> void:
	position.y -= velocidad * delta
	if position.y < 0:
		queue_free()


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemigo"):
		var explosion = escena_explosion.instantiate()
		explosion.position = position
		explosion.emitting = true
		get_parent().add_child(explosion)
		get_parent().reproducir_sonido_explosion()
		get_parent().incrementar_puntos()
		area.queue_free()
		queue_free()
