extends Area2D

var velocidad = 300

func _process(delta: float) -> void:
	position.y += velocidad * delta
