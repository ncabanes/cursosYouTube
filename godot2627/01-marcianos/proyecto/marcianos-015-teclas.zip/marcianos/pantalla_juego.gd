extends Node2D

var puntos : int = 0
var escena_disparo_enemigo

func _ready() -> void:
	escena_disparo_enemigo = load("res://disparo_enemigo.tscn")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func incrementar_puntos() -> void:
	puntos += 10
	#print(puntos)
	$TextoPuntos.text = "Puntos: " + str(puntos)

func reproducir_sonido_explosion() -> void:
	$SonidoExplosion.play()

func reproducir_sonido_disparo() -> void:
	$SonidoDisparo.play()


func _on_temporizador_disparo_enemigos_timeout() -> void:
	var enemigos = $ContenedorEnemigos.get_children()
	var enemigo_disparo = enemigos.pick_random()
	var disparo = escena_disparo_enemigo.instantiate()
	disparo.position = enemigo_disparo.position
	add_child(disparo)
