extends Node2D

var puntos : int = 0
var escena_disparo_enemigo
var escena_enemigo

func _ready() -> void:
	escena_disparo_enemigo = load("res://disparo_enemigo.tscn")
	escena_enemigo = load("res://enemigo.tscn")

func _process(delta: float) -> void:
	pass

func incrementar_puntos() -> void:
	puntos += 10
	$TextoPuntos.text = "Puntos: " + str(puntos)

func reproducir_sonido_explosion() -> void:
	$SonidoExplosion.play()

func reproducir_sonido_disparo() -> void:
	$SonidoDisparo.play()

func _on_temporizador_disparo_enemigos_timeout() -> void:
	var enemigos = $ContenedorEnemigos.get_children()
	if len(enemigos) > 0:
		var enemigo_disparo = enemigos.pick_random()
		var disparo = escena_disparo_enemigo.instantiate()
		disparo.position = enemigo_disparo.position
		add_child(disparo)
	else:
		if $TemporizadorDisparoEnemigos.wait_time > 0.1:
			$TemporizadorDisparoEnemigos.wait_time -= 0.1
		for fila in range(4):
			for columna in range(5):
				var enemigo = escena_enemigo.instantiate()
				enemigo.position.x = 120 + columna * 130
				enemigo.position.y = 80 + fila * 80
				$ContenedorEnemigos.add_child(enemigo)
