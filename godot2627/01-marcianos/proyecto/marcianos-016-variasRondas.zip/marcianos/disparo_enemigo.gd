extends Area2D

var velocidad = 300

func _process(delta: float) -> void:
	position.y += velocidad * delta
	if position.y > 800:
		queue_free()

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("nave"):
		get_tree().change_scene_to_file("res://bienvenida.tscn")
