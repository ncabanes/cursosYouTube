extends Node2D

var puntos : int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func incrementar_puntos() -> void:
	puntos += 10
	#print(puntos)
	$TextoPuntos.text = "Puntos: " + str(puntos)

func reproducir_sonido_explosion() -> void:
	$SonidoExplosion.play()

func reproducir_sonido_disparo() -> void:
	$SonidoDisparo.play()
