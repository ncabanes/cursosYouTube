package com.ncabanes.notif1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ncabanes.notif1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val CHANNEL_ID = "com.ncabanes.notif1"
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)

        builder.apply {
            setContentTitle("Notificación")
            setContentText("Esta es una notificación de prueba")
            setSmallIcon(R.mipmap.ic_launcher)
            priority = NotificationCompat.PRIORITY_DEFAULT
        }

        var idNotificacion = 10001
        fun notificar() {

            NotificationManagerCompat.from(this).
                notify(idNotificacion, builder.build())
        }

        val timer = object : CountDownTimer(5000, 1000) {
            override fun onTick(millisUntilFinished: Long) {  }
            override fun onFinish() { notificar()  }
        }

        binding.btNotificar.setOnClickListener {
            timer.start()
        }

    }
}