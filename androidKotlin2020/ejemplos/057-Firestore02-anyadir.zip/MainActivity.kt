package com.nachocabanes.firestore01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.firestore.FirebaseFirestore
import com.nachocabanes.firestore01.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db : FirebaseFirestore = FirebaseFirestore.getInstance()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btConsultar.setOnClickListener {

            var datos = ""
            db.collection("amigos")
                .get()
                .addOnSuccessListener { resultado ->
                    for(documento in resultado) {
                      datos += "${documento.id}: ${documento.data}\n"
                    }
                    binding.tvConsulta.text = datos
                }
                .addOnFailureListener { exception ->
                    binding.tvConsulta.text = "No se ha podido conectar"
                }
        }

        binding.btGuardar.setOnClickListener {
            if (binding.etNombre.text.isNotBlank() &&
                    binding.etEmail.text.isNotBlank() &&
                    binding.etId.text.isNotBlank()) {

                val dato = hashMapOf(
                        //"id" to binding.etId.text,
                        "nombre" to binding.etNombre.text.toString(),
                        "correo" to binding.etEmail.text.toString()
                )

                db.collection("amigos")
                    .document(binding.etId.text.toString())
                    .set(dato)
                    .addOnSuccessListener { _ ->
                        binding.tvConsulta.text = "Añadido correctamente"
                    }
                    .addOnFailureListener { _ ->
                        binding.tvConsulta.text = "No se ha podido añadir"
                    }

            }
        }
    }
}