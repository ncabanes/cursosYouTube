package com.ncabanes.sqlite01

import android.content.Context
import android.database.Cursor
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.ncabanes.sqlite01.databinding.ItemRecyclerviewBinding

class RecyclerViewAdapterAmigos
        : RecyclerView.Adapter<RecyclerViewAdapterAmigos.ViewHolder>(){

    lateinit var context : Context
    lateinit var cursor : Cursor

    fun RecyclerViewAdapterAmigos(context : Context,cursor : Cursor) {
        this.context = context
        this.cursor = cursor
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ViewHolder(inflater.inflate(R.layout.item_recyclerview,
                parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        cursor.moveToPosition(position)

        holder.tvNombre.text = cursor.getString(1)
        holder.tvEmail.text = cursor.getString(2)
    }

    override fun getItemCount(): Int {
        if (cursor == null)
            return 0
        else
            return cursor.count
    }



    inner class ViewHolder: RecyclerView.ViewHolder {

        val tvNombre: TextView
        val tvEmail: TextView

        constructor(view: View) : super(view) {
            val bindingItemsRV = ItemRecyclerviewBinding.bind(view)
            tvNombre = bindingItemsRV.tvItemNombre
            tvEmail = bindingItemsRV.tvItemEmail

            view.setOnClickListener {
                Toast.makeText(context,
                    "${tvNombre.text}, ${tvEmail.text}",
                    Toast.LENGTH_SHORT).show()
            }

        }
    }



}