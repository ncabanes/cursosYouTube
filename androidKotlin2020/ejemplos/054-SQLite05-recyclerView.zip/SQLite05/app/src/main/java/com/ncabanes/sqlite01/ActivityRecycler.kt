package com.ncabanes.sqlite01

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ncabanes.sqlite01.databinding.ActivityRecyclerBinding

class ActivityRecycler : AppCompatActivity() {

    private lateinit var binding: ActivityRecyclerBinding
    private lateinit var amigosDBHelper: miSQLiteHelper
    private lateinit var db: SQLiteDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRecyclerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        amigosDBHelper = miSQLiteHelper(this)

        db = amigosDBHelper.readableDatabase
        val cursor : Cursor = db.rawQuery(
                "SELECT * FROM amigos", null)

        val adaptador = RecyclerViewAdapterAmigos()
        adaptador.RecyclerViewAdapterAmigos(this, cursor)

        binding.rvDatos.setHasFixedSize(true)
        binding.rvDatos.layoutManager = LinearLayoutManager(this)
        binding.rvDatos.adapter = adaptador
    }

    override fun onDestroy() {
        super.onDestroy()
        db.close()
    }
}