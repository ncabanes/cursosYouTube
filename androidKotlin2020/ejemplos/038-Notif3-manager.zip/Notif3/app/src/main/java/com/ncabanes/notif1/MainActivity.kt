package com.ncabanes.notif1

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ncabanes.notif1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val intentPrevio = Intent(this, ActivityNotificacion::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent : PendingIntent = PendingIntent.getActivity(
                this, 0, intentPrevio, 0
        )

        val CHANNEL_ID = "com.ncabanes.notif1"
        crearCanalDeNotificacion(CHANNEL_ID, "Notif1",
            "Ejemplo de notificación",
            NotificationManager.IMPORTANCE_DEFAULT
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)

        builder.apply {
            setContentTitle("Notificación")
            setContentText("Esta es una notificación de prueba")
            setSmallIcon(R.mipmap.ic_launcher)
            priority = NotificationCompat.PRIORITY_DEFAULT
            setContentIntent(pendingIntent)
            setAutoCancel(true)
        }

        var idNotificacion = 10001
        binding.btNotificar.setOnClickListener {
            NotificationManagerCompat.from(this).
                notify( idNotificacion, builder.build() )
        }

    }

    private fun crearCanalDeNotificacion(
            canal: String, nombre: String,
            descripcion: String, importancia: Int
            ) {
        // Creamos el canal de notificación sólo si es API 26+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(canal, nombre, importancia).apply {
                description = descripcion
            }

            // Y registramos el canal en el sistema
            val notificationManager: NotificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE)
            as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}