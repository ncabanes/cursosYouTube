package com.ncabanes.notif1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityNotificacion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notificacion)
    }
}