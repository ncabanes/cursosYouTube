package com.ncabanes.sharedprefs

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ncabanes.sharedprefs.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    var numero = 0;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lateinit var binding : ActivityMainBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pref = applicationContext.getSharedPreferences(
            "datos", 0)
        numero = pref.getInt("contador", 0)
        binding.tvDato.text = numero.toString()

        binding.botonGuardar.setOnClickListener {
            numero++
            binding.tvDato.text = numero.toString()

            val pref = applicationContext.getSharedPreferences(
                "datos", 0)
            val editor = pref.edit()
            editor.putInt("contador", numero)
            editor.apply()
        }
    }
}