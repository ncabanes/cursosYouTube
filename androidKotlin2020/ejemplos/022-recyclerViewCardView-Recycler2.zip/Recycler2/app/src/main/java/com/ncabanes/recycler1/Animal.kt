package com.ncabanes.recycler1

data class Animal(
    val nombre: String,
    val latin: String,
    val imagen: Int) {
}
