package com.ncabanes.recycler1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val adaptador : AdapterAnimal = AdapterAnimal()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rvAnimales = findViewById(R.id.rvAnimales) as RecyclerView
        rvAnimales.setHasFixedSize(true)
        rvAnimales.layoutManager = LinearLayoutManager(this)
        adaptador.AdapterAnimal(crearListaAnimales(), this)
        rvAnimales.adapter = adaptador
    }

    private fun crearListaAnimales(): MutableList<Animal> {
        val animals: MutableList<Animal> = arrayListOf()
        animals.add(Animal("Cisne", "Cygnus olor", R.drawable.cisne))
        animals.add(Animal("Erizo", "Erinaceinae", R.drawable.erizo))
        animals.add(Animal("Gato", "Felis catus", R.drawable.gato))
        animals.add(Animal("Gorrión", "Passer domesticus", R.drawable.gorrion))
        animals.add(Animal("Mapache", "Procyon", R.drawable.mapache))
        animals.add(Animal("Oveja", "Ovis aries", R.drawable.oveja))
        animals.add(Animal("Perro", "Canis lupus familiaris", R.drawable.perro))
        animals.add(Animal("Tigre", "Panthera tigris", R.drawable.tigre))
        animals.add(Animal("Zorro", "Vulpes vulpes", R.drawable.zorro))
        return animals
    }
}