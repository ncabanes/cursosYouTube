package com.ncabanes.recycler1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class AdapterAnimal : RecyclerView.Adapter<AdapterAnimal.ViewHolder>() {

    var animales: MutableList<Animal> = ArrayList()
    lateinit var contexto: Context

    fun AdapterAnimal(lista: MutableList<Animal>, contexto: Context) {
        this.animales = lista
        this.contexto = contexto
    }

    override fun onBindViewHolder(
        holder: AdapterAnimal.ViewHolder,
        position: Int
    ) {
        val animal = animales[position]
        holder.bind(animal, contexto)
    }

    override fun getItemCount(): Int {
        return animales.size
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): AdapterAnimal.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ViewHolder(
            layoutInflater.inflate(
                R.layout.elemento_lista_animales,
                parent,
                false
            )
        )
    }


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        private val nombre = view.findViewById(R.id.tvNombre) as TextView
        private val latin = view.findViewById(R.id.tvNombreLatin) as TextView
        private val imagen = view.findViewById(R.id.ivImagen) as ImageView

        fun bind(animal: Animal, context: Context) {
            nombre.text = animal.nombre
            latin.text = animal.latin
            imagen.setImageResource(animal.imagen!!)
            itemView.setOnClickListener {
                Toast.makeText(
                    context,
                    animal.nombre,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    }
}