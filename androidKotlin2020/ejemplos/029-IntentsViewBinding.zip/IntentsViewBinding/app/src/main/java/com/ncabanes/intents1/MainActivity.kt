package com.ncabanes.intents1

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.ncabanes.intents1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        //setContentView(R.layout.activity_main)
        setContentView(binding.root)

        //val boton : Button = findViewById(R.id.botonSaludar)
        //val editText : EditText = findViewById(R.id.etNombre)

        binding.botonSaludar.setOnClickListener {
            val miIntent = Intent(this,
                SegundaActivity::class.java).apply {
                    putExtra("nombre",
                            binding.etNombre.text.toString())
            }
            startActivityForResult(miIntent, 1234)
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        val tvResultado : TextView = findViewById(R.id.tvResultado)

        if (requestCode == 1234)
        {
            if (resultCode == Activity.RESULT_OK) {
                val resultado = data?.getFloatExtra("valoracion", 0f)
                tvResultado.text = "Te ha gustado y lo has valorado con $resultado estrellas"
                tvResultado.visibility = View.VISIBLE
            }

            if (resultCode == Activity.RESULT_CANCELED) {
                tvResultado.text = "No te ha gustado"
                tvResultado.visibility = View.VISIBLE
            }
        }
    }
}