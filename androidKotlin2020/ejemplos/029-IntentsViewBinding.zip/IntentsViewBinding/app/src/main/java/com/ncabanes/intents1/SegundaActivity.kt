package com.ncabanes.intents1

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import com.ncabanes.intents1.databinding.ActivitySegundaBinding

class SegundaActivity : AppCompatActivity() {

    lateinit var binding: ActivitySegundaBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySegundaBinding.inflate(layoutInflater)

        // setContentView(R.layout.activity_segunda)
        setContentView(binding.root)

        //val botonSi : Button = findViewById(R.id.btSi)
        //val botonNo : Button = findViewById(R.id.btNo)

        val dato = intent.getStringExtra("nombre")
        //val textView : TextView = findViewById(R.id.tvSaludo)
        //val ratingBar: RatingBar = findViewById(R.id.ratingBar)

        binding.tvSaludo.text = "Hola $dato. ¿Te ha gustado el saludo?"

        binding.btSi.setOnClickListener {

            val intentResultado = Intent().apply {
                putExtra("valoracion", binding.ratingBar.rating)
            }

            setResult(Activity.RESULT_OK, intentResultado)
            finish()
        }

        binding.btNo.setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }
}