package com.ncabanes.intent4web

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btWeb : Button = findViewById(R.id.btWeb)
        val btUbicacion : Button = findViewById(R.id.btUbicacion)
        val btLlamar : Button = findViewById(R.id.btLlamar)

        btWeb.setOnClickListener {
            val miIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("http://www.museodelprado.es")
            )
            startActivity(miIntent)
        }

        btUbicacion.setOnClickListener {
            val miIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("geo:40.41383896056784, -3.692105644930656?z=17")
            )
            startActivity(miIntent)
        }

        btLlamar.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    val miIntent = Intent(
                        Intent.ACTION_CALL,
                        Uri.parse("tel:555555555")
                    )
                    startActivity(miIntent)
                }
                else {
                    Toast.makeText(this,
                        "No hay permiso para llamada",
                        Toast.LENGTH_LONG).show()
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.CALL_PHONE),
                        123
                    )
                }
        }
    }
}