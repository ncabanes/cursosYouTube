package com.ncabanes.menu5actionmode

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.AbsListView
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    companion object {
        val datos: MutableList<String> =
                mutableListOf("uno", "dos", "tres", "cuatro",
                        "cinco", "seis", "siete", "ocho",
                        "nueve", "diez", "once", "doce",
                        "trece", "catorce", "quince")
        var isActionMode: Boolean = false
        public var actionMode: ActionMode? = null
        var seleccion: MutableList<String> = ArrayList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adaptador = AdapterListaDatos(this, datos)
        val lista: ListView = findViewById(R.id.miLista)
        lista.adapter = adaptador

        with(lista) {
            choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL
            setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                    val inflater = menuInflater
                    inflater.inflate(R.menu.menu_action, menu)
                    actionMode = mode
                    isActionMode = true
                    return true
                }

                override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                    return false
                }

                override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                    return when (item!!.itemId) {
                        R.id.opcionBorrar -> {
                            Toast.makeText(
                                    context,
                                    "Borrado",
                                    Toast.LENGTH_LONG).show()
                            adaptador.borrarDatos(seleccion)
                            mode!!.finish()
                            true
                        }
                        R.id.opcionCompartir -> {
                            Toast.makeText(
                                    context,
                                    "Compartido",
                                    Toast.LENGTH_LONG).show()
                            true
                        }
                        else -> false
                    }
                }

                override fun onDestroyActionMode(mode: ActionMode?) {
                    isActionMode = false
                    actionMode = null
                    seleccion.clear()
                }

                override fun onItemCheckedStateChanged(mode: ActionMode?, position: Int, id: Long, checked: Boolean) {
                    // Nada
                }

            })
        }

    }
}