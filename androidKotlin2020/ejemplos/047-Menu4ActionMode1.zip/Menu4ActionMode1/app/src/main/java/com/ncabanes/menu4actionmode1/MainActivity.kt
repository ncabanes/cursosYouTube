package com.ncabanes.menu4actionmode1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private var actionMode: ActionMode? = null

    private val actionModeCallback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            val inflater = menuInflater
            inflater.inflate(R.menu.menu_action, menu)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            return false
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            actionMode = null
        }

        override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
            return when(item!!.itemId) {
                R.id.opcion01 -> {
                    Toast.makeText(applicationContext,
                        "Escogida la opción 1",
                        Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.opcion02 -> {
                    Toast.makeText(applicationContext,
                            "Escogida la opción 2",
                            Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val iv : ImageView = findViewById(R.id.imageView)
        iv.setOnLongClickListener {
            when(actionMode) {
                null -> {
                    actionMode = it.startActionMode(actionModeCallback)
                    it.isSelected = true
                    true
                }
                else -> false
            }
        }
    }
}