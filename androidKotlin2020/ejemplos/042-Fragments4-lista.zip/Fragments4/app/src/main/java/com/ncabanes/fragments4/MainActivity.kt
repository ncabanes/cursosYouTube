package com.ncabanes.fragments4

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity(), FragmentLista.SelectorElementos {

    val descripciones = arrayOf("Descripción 1","Descripción 2",
        "Descripción 3","Descripción 4","Descripción 5",
        "Descripción 6","Descripción 7")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun EscogerElemento(posicion: Int) {
        val tv : TextView = findViewById(R.id.tvDetalles)
        tv.text = descripciones[posicion]

        if(getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_PORTRAIT) {
            val manager = supportFragmentManager
            manager.beginTransaction()
                .show(manager.findFragmentById(R.id.fragment2)!!)
                .hide(manager.findFragmentById(R.id.fragment)!!)
                .addToBackStack(null)
                .commit()
        } else {
            val manager = supportFragmentManager
            manager.beginTransaction()
                .show(manager.findFragmentById(R.id.fragment2)!!)
                .show(manager.findFragmentById(R.id.fragment)!!)
                .commit()
        }
    }
}