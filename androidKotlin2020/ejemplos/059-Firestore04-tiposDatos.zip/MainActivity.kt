package com.nachocabanes.firestore01

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.nachocabanes.firestore01.databinding.ActivityMainBinding
import java.lang.Exception
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    var fechaEscogida = Calendar.getInstance()

    fun guardarDatos(db: FirebaseFirestore) {
        if (binding.etNombre.text.isNotBlank() &&
                binding.etEmail.text.isNotBlank() &&
                binding.etId.text.isNotBlank()) {

            val dato = hashMapOf(
                    //"id" to binding.etId.text,
                    "nombre" to binding.etNombre.text.toString(),
                    "correo" to binding.etEmail.text.toString(),
                    "fecha" to Timestamp(fechaEscogida.timeInMillis/1000,
                        0)
            )

            db.collection("amigos")
                    .document(binding.etId.text.toString())
                    .set(dato)
                    .addOnSuccessListener { _ ->
                        binding.tvConsulta.text = "Procesado correctamente"
                    }
                    .addOnFailureListener { _ ->
                        binding.tvConsulta.text = "No se ha podido procesar"
                    }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db: FirebaseFirestore = FirebaseFirestore.getInstance()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btConsultar.setOnClickListener {

            var datos = ""
            db.collection("amigos")
                    .get()
                    .addOnSuccessListener { resultado ->
                        for (documento in resultado) {
                            //datos += "${documento.id}: ${documento.data}\n"
                            val nombre = documento["nombre"].toString()
                            val correo = documento["correo"].toString()
                            var fecha = "(fecha no indicada)"
                            try {
                                if (documento["fecha"] != null)
                                    fecha = (documento["fecha"] as Timestamp).toDate().toString()
                            }
                            catch (e : Exception) {
                            }
                            datos += "${documento.id}: $nombre, $correo : $fecha\n"
                        }
                        binding.tvConsulta.text = datos
                    }
                    .addOnFailureListener { exception ->
                        binding.tvConsulta.text = "No se ha podido conectar"
                    }
        }

        binding.btGuardar.setOnClickListener {
            guardarDatos(db)
        }

        binding.btModificar.setOnClickListener {
            guardarDatos(db)
        }

        binding.btBorrar.setOnClickListener {
            if (binding.etId.text.isNotBlank()) {

                db.collection("amigos")
                        .document(binding.etId.text.toString())
                        .delete()
                        .addOnSuccessListener { _ ->
                            binding.tvConsulta.text = "Borrado correctamente"
                        }
                        .addOnFailureListener { _ ->
                            binding.tvConsulta.text = "No se ha podido borrar"
                        }
            }
        }

        val listenerFecha = DatePickerDialog.OnDateSetListener {
            datePicker, anyo, mes, dia ->

            fechaEscogida.clear()  // Para borrar H, M, S
            fechaEscogida.set(Calendar.YEAR, anyo)
            fechaEscogida.set(Calendar.MONTH, mes)
            fechaEscogida.set(Calendar.DAY_OF_MONTH, dia)

            binding.etFecha.setText(Date(fechaEscogida.timeInMillis).toString())
        }

        var cal = Calendar.getInstance()

        binding.btFecha.setOnClickListener {
            DatePickerDialog(this,
                    listenerFecha,
                    cal.get(Calendar.YEAR),
                    cal.get(Calendar.MONTH),
                    cal.get(Calendar.DAY_OF_MONTH)).show()
        }
    }
}