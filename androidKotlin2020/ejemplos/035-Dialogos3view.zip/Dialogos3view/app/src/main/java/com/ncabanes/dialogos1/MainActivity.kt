package com.ncabanes.dialogos1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.layout_dialogo.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        // builder.setMessage("Algo ha ido mal. ¿Deseas reintentar?")
        val inflater = layoutInflater
        builder.setView(inflater.inflate(R.layout.layout_dialogo, null))
        builder.setPositiveButton(android.R.string.ok) {
            dialogo, _ ->
                val nombre = (dialogo as AlertDialog).etNombre.text
                Toast.makeText(this,
                    "Hola $nombre",
                    Toast.LENGTH_LONG).show()
        }
        builder.setNegativeButton("Cancelar", null)
        //builder.setNeutralButton("Recordar más tarde", null)

        builder.show()
    }
}