package com.ncabanes.depuracion

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tv : TextView = findViewById(R.id.textView)
        val et : EditText = findViewById(R.id.editText)

        var n = 10
        n ++
        n += 3
        n -= 7
        tv.text = "Hola"
        n *= 5
        et.text = "Adiós" as Editable // Error en tiempo de ejecución
    }
}