package com.ncabanes.intent4web

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btWeb : Button = findViewById(R.id.btWeb)
        val btUbicacion : Button = findViewById(R.id.btUbicacion)

        btWeb.setOnClickListener {
            val miIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("http://www.museodelprado.es")
            )
            startActivity(miIntent)
        }

        btUbicacion.setOnClickListener {
            val miIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("geo:40.41383896056784, -3.692105644930656?z=17")
            )
            startActivity(miIntent)
        }
    }
}