package com.ncabanes.lista1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.elemento_de_lista.view.*

class AdapterNegocio : BaseAdapter {

    var contexto : Context? = null
    var listaDatos = ArrayList<Negocio>()

    constructor(
        contexto: Context,
        lista : ArrayList<Negocio>
    ) :super() {
        this.contexto = contexto
        this.listaDatos = lista
    }

    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup?
    ): View {
        val dato = listaDatos[position]

        var inflator = LayoutInflater.from(contexto)
        var viewDato = inflator.inflate(R.layout.elemento_de_lista, null)
        viewDato.tvNombre.text = dato.nombre
        viewDato.tvUbicacion.text = dato.ubicacion
        viewDato.ivTipoDeNegocio.setImageResource(dato.imagen)

        return viewDato
    }

    override fun getCount(): Int {
        return listaDatos.size
    }

    override fun getItem(position: Int): Any {
        return listaDatos[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }


}