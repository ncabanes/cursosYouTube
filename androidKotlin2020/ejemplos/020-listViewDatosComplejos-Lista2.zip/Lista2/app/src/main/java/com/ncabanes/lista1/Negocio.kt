package com.ncabanes.lista1

data class Negocio (
    val nombre: String,
    val ubicacion: String,
    val imagen: Int) {

}