package com.ncabanes.lista1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    /*
    val datos = arrayOf("uno", "dos", "tres", "cuatro",
            "cinco", "seis", "siete", "ocho",
            "nueve", "diez", "once", "doce",
            "trece", "catorce", "quince")
     */

    var datos = ArrayList<Negocio>()
    var adaptador: AdapterNegocio? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        datos.add( Negocio("Supermercado Nacho", "Su calle", R.drawable.img_supermercado))
        datos.add( Negocio("Cine Héctor", "Otra calle", R.drawable.img_cines))
        datos.add( Negocio("Bar Javier", "Calle 3", R.drawable.img_supermercado))

        adaptador = AdapterNegocio(this, datos)
        miLista.adapter = adaptador


    }

    override fun onStart() {
        super.onStart()

        miLista.onItemClickListener =
            object : AdapterView.OnItemClickListener{
                override fun onItemClick(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    Toast.makeText(
                        applicationContext,
                        "Escogido: ${datos[position].nombre}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }
}