package com.ncabanes.menu2contextual

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    val datos = arrayOf("uno", "dos", "tres", "cuatro",
        "cinco", "seis", "siete", "ocho",
        "nueve", "diez", "once", "doce",
        "trece", "catorce", "quince")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val adaptador = ArrayAdapter(this,
            android.R.layout.simple_list_item_1,
            datos)

        val lista : ListView = findViewById(R.id.listaDatos)
        lista.adapter = adaptador

        lista.onItemClickListener =
            object : AdapterView.OnItemClickListener{
                override fun onItemClick(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    Toast.makeText(
                        applicationContext,
                        "Escogido: ${lista.getItemAtPosition(position)}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

        registerForContextMenu(lista)
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)

        val inflater = menuInflater
        inflater.inflate(R.menu.menu_contextual, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {

        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        val posicion = info.position
        val nombre = datos[posicion]

        return when (item.itemId) {
            R.id.opcion1 -> {
                Toast.makeText(this,
                    "Opción 1 en $nombre", Toast.LENGTH_LONG).show()
                return true
            }
            R.id.opcion2 -> {
                Toast.makeText(this,
                    "Opción 2 en $nombre", Toast.LENGTH_LONG).show()
                return true
            }
            else -> return super.onContextItemSelected(item)
        }
    }
}