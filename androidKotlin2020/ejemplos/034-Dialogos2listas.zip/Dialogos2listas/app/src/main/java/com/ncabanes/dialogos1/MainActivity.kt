package com.ncabanes.dialogos1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val lista = arrayOf("Uno", "Dos", "Tres")

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Lista de datos")
        // builder.setMessage("Algo ha ido mal. ¿Deseas reintentar?")

        // Lista convencional

        /*
        builder.setItems(lista) { id, posicion ->
            Toast.makeText(this,
                    lista[posicion],
                    Toast.LENGTH_LONG).show()
        }
         */

        // Lista elección única

        /*
        builder.setSingleChoiceItems(lista, -1) { _, posicion ->
            Toast.makeText(this,
                    lista[posicion],
                    Toast.LENGTH_LONG).show()
        }

        builder.setPositiveButton(android.R.string.ok) {  dialogo, _ ->
            val posicionEscogida = (dialogo as AlertDialog).listView.checkedItemPosition
            Toast.makeText(this,
                "Has escogido ${lista[posicionEscogida]}",
                Toast.LENGTH_LONG).show()
        }

         */

        // Lista elección múltiple

        val escogidos = ArrayList<Int>()

        builder.setMultiChoiceItems(lista, null) { _, posicion, isChecked ->
            if (isChecked) {
                escogidos.add(posicion)
                Toast.makeText(this,
                        "Activado $posicion",
                        Toast.LENGTH_LONG).show()
            }
            else {
                escogidos.remove(posicion)
                Toast.makeText(this,
                        "Desactivado $posicion",
                        Toast.LENGTH_LONG).show()
            }
        }

        builder.setPositiveButton(android.R.string.ok) {  dialogo, _ ->
            var respuesta = ""
            if (escogidos.size > 0) {
                for(item in escogidos) {
                    respuesta += lista[item] + " "
                }
            }
            else
                respuesta = "No se ha escogido ningún elemento"

            Toast.makeText(this,
                    respuesta,
                    Toast.LENGTH_LONG).show()
        }

        builder.setNegativeButton("Cancelar", null)


        //builder.setNeutralButton("Recordar más tarde", null)

        builder.show()
    }
}