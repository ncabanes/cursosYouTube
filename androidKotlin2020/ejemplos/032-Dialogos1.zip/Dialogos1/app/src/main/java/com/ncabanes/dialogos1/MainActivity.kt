package com.ncabanes.dialogos1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("Algo ha ido mal. ¿Deseas reintentar?")
        builder.setPositiveButton(android.R.string.ok) {
            dialog, which ->
                Toast.makeText(this,
                "Has aceptado",
                Toast.LENGTH_LONG).show()
        }
        builder.setNegativeButton("Cancelar", null)
        //builder.setNeutralButton("Recordar más tarde", null)

        builder.show()
    }
}