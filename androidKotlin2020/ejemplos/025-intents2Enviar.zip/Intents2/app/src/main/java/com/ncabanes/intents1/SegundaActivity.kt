package com.ncabanes.intents1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class SegundaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segunda)

        val dato = intent.getStringExtra("nombre")
        val textView : TextView = findViewById(R.id.tvSaludo)
        textView.text = "Hola $dato"
    }
}