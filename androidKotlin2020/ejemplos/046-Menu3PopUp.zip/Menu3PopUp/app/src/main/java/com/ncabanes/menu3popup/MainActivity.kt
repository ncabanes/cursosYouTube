package com.ncabanes.menu3popup

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun mostrarPopup(v: View) {
        PopupMenu(this, v).apply {
            inflate(R.menu.menu_imagen)
            setOnMenuItemClickListener {
                when(it!!.itemId) {
                    R.id.opcion1 -> {
                        Toast.makeText(this@MainActivity,
                            "Opción 1 en la imagen",
                            Toast.LENGTH_SHORT).show()
                        true
                    }
                    R.id.opcion2 -> {
                        Toast.makeText(this@MainActivity,
                            "Opción 2 en la imagen",
                            Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
        }.show()
    }
}