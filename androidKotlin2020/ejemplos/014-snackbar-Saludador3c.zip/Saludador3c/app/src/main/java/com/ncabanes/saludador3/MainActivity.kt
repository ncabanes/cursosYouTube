package com.ncabanes.saludador3

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btSaludar.setOnClickListener {
            if (! etNombre.text.isEmpty()) {
                // tvRespuesta.text = "Hola ${etNombre.text}"
                /*
                Toast.makeText(applicationContext,
                        "Hola ${etNombre.text}",
                        Toast.LENGTH_LONG
                ).show()
                 */

                Snackbar.make(
                        miLayout,
                        "Hola ${etNombre.text}",
                        Snackbar.LENGTH_LONG
                ).setAction("De acuerdo") {
                    miLayout.setBackgroundColor(Color.CYAN)
                }.show()
            }
        }
    }
}