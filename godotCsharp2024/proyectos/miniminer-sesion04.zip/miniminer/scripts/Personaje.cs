using Godot;
using System;

public partial class Personaje : CharacterBody2D
{
	public const float Speed = 300.0f;
	public const float JumpVelocity = -400.0f;

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		// Add the gravity.
		if (!IsOnFloor())
		{
			velocity += GetGravity() * (float)delta;
		}

		// Handle Jump.
		if (Input.IsActionJustPressed("ui_accept") && IsOnFloor())
		{
			velocity.Y = JumpVelocity;
		}

		velocity.X = 0;

		if (Input.IsActionPressed("ui_right"))
		{
			velocity.X = Speed;
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Play();
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Scale = new Vector2(1, 1);
        }
		else if (Input.IsActionPressed("ui_left"))
        {
            velocity.X = -Speed;
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Play();
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Scale = new Vector2(-1, 1);
        }
		else
		{
			GetNode<AnimatedSprite2D>("AnimatedSprite2D").Stop();
        }

        Velocity = velocity;
		MoveAndSlide();
	}
}
