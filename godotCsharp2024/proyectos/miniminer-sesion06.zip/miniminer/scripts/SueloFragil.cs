using Godot;
using System;

public partial class SueloFragil : AnimatableBody2D
{
	private RayCast2D rayo1, rayo2;
	private float velocidadCaida = 10;
	private float desplazamiento = 0;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		rayo1 = GetNode<RayCast2D>("RayCast2D1");
		rayo2 = GetNode<RayCast2D>("RayCast2D2");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (rayo1.IsColliding() || rayo2.IsColliding())
		{
			Position += new Vector2(0, (float) (velocidadCaida * delta));
			desplazamiento += (float)(velocidadCaida * delta);
			if (desplazamiento > 32)
			{
				QueueFree();
			}
        }
	}
}
