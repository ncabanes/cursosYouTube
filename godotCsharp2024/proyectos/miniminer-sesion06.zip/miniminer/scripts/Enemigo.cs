using Godot;
using System;

public partial class Enemigo : Area2D
{
	[Export] private Vector2 posInicial;
	[Export] private Vector2 posFinal;
	[Export] private float velocidad;
	private Vector2 destino;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Position = posInicial;
		destino = posFinal;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Position = Position.MoveToward(destino, (float)(velocidad * delta));
		if (Position.DistanceTo(destino) < 5)
		{
			if (destino == posFinal)
			{
				destino = posInicial;
				GetNode<AnimatedSprite2D>("AnimatedSprite2D").Scale = new Vector2(-1, 1);
			}
			else
			{
				destino = posFinal;
				GetNode<AnimatedSprite2D>("AnimatedSprite2D").Scale = new Vector2(1, 1);
			}
		}
	}
}
