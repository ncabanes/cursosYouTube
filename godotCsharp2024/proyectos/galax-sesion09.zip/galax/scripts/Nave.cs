using Godot;
using System;

public partial class Nave : Area2D
{
	private PackedScene disparo;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		disparo = GD.Load<PackedScene>("res://disparo.tscn");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("ui_right"))
			Position += new Vector2(100 * (float) delta, 0);
		if (Input.IsActionPressed("ui_left"))
            Position += new Vector2(-100 * (float) delta, 0);
		if (Input.IsActionJustPressed("ui_accept"))
		{
			var nuevoDisparo = disparo.Instantiate();
			((Area2D) nuevoDisparo).Position = this.Position;
			GetParent().AddChild(nuevoDisparo);
		}
    }
}
