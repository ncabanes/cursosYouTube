using Godot;
using System;
using System.Threading.Tasks;

public partial class EscenaDeJuego : Node2D
{
	private int puntos;
    private PackedScene explosion;
	private Node contenedorEnemigos;

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
		puntos = 0;
        explosion = GD.Load<PackedScene>("res://explosion.tscn");
		contenedorEnemigos = GetNode("ContenedorEnemigos");
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public async void Explotar(float x, float y)
	{
        var nuevaExplosion = explosion.Instantiate();
        ((CpuParticles2D)nuevaExplosion).Position = new Vector2(x, y);
        ((CpuParticles2D)nuevaExplosion).Emitting = true;
        AddChild(nuevaExplosion);
		GD.Print("Explotando. Quedan: " +
			contenedorEnemigos.GetChildCount());
		if (contenedorEnemigos.GetChildCount() <= 1)
		{
			GetNode<Label>("TextoPartidaGanada").Visible = true;
			await Task.Delay(2000);
			GetTree().ChangeSceneToFile("res://bienvenida.tscn");
		}
    }

	public void IncrementarPuntos()
	{
		puntos += 10;
		GD.Print(puntos);
		GetNode<Label>("TextoPuntos").Text = 
			"Puntos: " + puntos;
	}
}
