using Godot;
using System;

public partial class Bienvenida : Control
{
	private Sprite2D fondo;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		fondo = GetNode<Sprite2D>("Fondo");
		GestorDeJuego.Puntos = 0;
		GestorDeJuego.Vidas = 3;
		GestorDeJuego.Nivel = 1;
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		fondo.Position += new Vector2(0, -100 * (float)delta);
		if (fondo.Position.Y < -512)
		{
			fondo.Position = new Vector2(0, 0);
		}
	}

	public void _on_boton_comenzar_pressed()
	{
		GetTree().ChangeSceneToFile("res://escena_de_juego.tscn");
	}
}
