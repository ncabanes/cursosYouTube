using Godot;
using System;

public partial class GestorDeJuego : Node
{
	public static int Puntos = 0;
    public static int Vidas = 3;
    public static int Nivel = 1;
    public static int Velocidad = 150;

	public static AudioStreamPlayer SonidoDisparo;
	public static AudioStreamPlayer SonidoDisparoEnemigo;
	public static AudioStreamPlayer SonidoExplosion;

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
		SonidoDisparo = GetNode<AudioStreamPlayer>("SonidoDisparo");
		SonidoDisparoEnemigo = GetNode<AudioStreamPlayer>("SonidoDisparoEnemigo");
        SonidoExplosion = GetNode<AudioStreamPlayer>("SonidoExplosion");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
}
