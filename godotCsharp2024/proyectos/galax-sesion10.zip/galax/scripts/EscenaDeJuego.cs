using Godot;
using System;
using System.Threading.Tasks;

public partial class EscenaDeJuego : Node2D
{
	private int puntos;
    private PackedScene explosion;
	private Node contenedorEnemigos;
	private bool juegoActivo = true;
	private int tiempoHastaDisparo = 3000;

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
		puntos = 0;
        explosion = GD.Load<PackedScene>("res://explosion.tscn");
		contenedorEnemigos = GetNode("ContenedorEnemigos");
		PrepararDisparo();
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public async void Explotar(float x, float y)
	{
        var nuevaExplosion = explosion.Instantiate();
        ((CpuParticles2D)nuevaExplosion).Position = new Vector2(x, y);
        ((CpuParticles2D)nuevaExplosion).Emitting = true;
        AddChild(nuevaExplosion);
		GD.Print("Explotando. Quedan: " +
			contenedorEnemigos.GetChildCount());
		if (contenedorEnemigos.GetChildCount() <= 1)
		{
			GetNode<Label>("TextoPartidaGanada").Visible = true;
			await Task.Delay(2000);
			GetTree().ChangeSceneToFile("res://bienvenida.tscn");
		}
    }

	public void IncrementarPuntos()
	{
		puntos += 10;
		GD.Print(puntos);
		GetNode<Label>("TextoPuntos").Text = 
			"Puntos: " + puntos;
	}

	public async void PrepararDisparo()
	{
		while (juegoActivo)
		{
			await Task.Delay(tiempoHastaDisparo);
			tiempoHastaDisparo = GD.RandRange(1000, 2500);
			Disparar();
		}
	}

	public void Disparar()
	{
		int numEnemigo = GD.RandRange(0, contenedorEnemigos.GetChildCount()-1);
		GD.Print("Enemigo disparando " + numEnemigo);
		GetNode("ContenedorEnemigos").GetChild<Enemigo>(numEnemigo).Disparar();
	}
}
