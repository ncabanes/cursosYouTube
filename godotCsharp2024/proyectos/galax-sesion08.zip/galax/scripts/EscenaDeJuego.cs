using Godot;
using System;

public partial class EscenaDeJuego : Node2D
{
	private int puntos;
    private PackedScene explosion;

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
		puntos = 0;
        explosion = GD.Load<PackedScene>("res://explosion.tscn");
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}

	public void Explotar(float x, float y)
	{
        var nuevaExplosion = explosion.Instantiate();
        ((CpuParticles2D)nuevaExplosion).Position = new Vector2(x, y);
        ((CpuParticles2D)nuevaExplosion).Emitting = true;
        AddChild(nuevaExplosion);
    }

	public void IncrementarPuntos()
	{
		puntos += 10;
		GD.Print(puntos);
		GetNode<Label>("TextoPuntos").Text = 
			"Puntos: " + puntos;
	}
}
