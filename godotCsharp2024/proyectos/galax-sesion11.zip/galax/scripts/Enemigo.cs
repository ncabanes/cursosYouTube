using Godot;
using System;

public partial class Enemigo : Area2D
{
	private Vector2 velocidad;
	private AnimatedSprite2D animacion;
	private float xMax, xMin;
    private PackedScene disparo;
    private Vector2 posicionInicial;

    // Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
		velocidad = new Vector2(150, 0);
		animacion = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		animacion.Play();
		xMin = Position.X - 200;
		xMax = Position.X + 200;
        disparo = GD.Load<PackedScene>("res://disparo_enemigo.tscn");
        posicionInicial = Position;
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Position += velocidad * (float) delta;
		if (Position.X > xMax)
		{
            velocidad = new Vector2(-150, 0);
        }
        if (Position.X < xMin)
        {
            velocidad = new Vector2(150, 0);
        }
    }

	public void Disparar()
	{
        var nuevoDisparo = disparo.Instantiate();
        ((Area2D)nuevoDisparo).Position = this.Position;
        GetParent().GetParent().AddChild(nuevoDisparo);
    }

    public void Recolocar()
    {
        Position = posicionInicial;
    }
}
