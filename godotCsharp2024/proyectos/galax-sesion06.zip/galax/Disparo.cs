using Godot;
using System;

public partial class Disparo : Area2D
{
    private Vector2 velocidad;
    
	// Called when the node enters the scene tree for the first time.
    public override void _Ready()
	{
        velocidad = new Vector2(0, -150);
    }

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
        Position += velocidad * (float)delta;
        if (Position.X < -100)
        {
            QueueFree();
        }
    }
}
