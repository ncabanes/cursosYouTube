﻿using System;


class Mueble
{
    protected string codigo;
    protected string descripcion;
    protected string material;
    
    public Mueble(string codigo, string descripcion, string material)
    {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.material = material;
    }

    public Mueble(string codigo, string descripcion)
        : this (codigo, descripcion, "Madera")
    {
    }

    public string Codigo
    {
        get { return codigo; }
        set { codigo = value; }
    }

    public string Descripcion
    {
        get { return descripcion; }
        set { descripcion = value; }
    }

    public string Material
    {
        get { return material; }
        set { material = value; }
    }

    public override string ToString()
    {
        return Codigo + " - " + Descripcion;
    }

}
