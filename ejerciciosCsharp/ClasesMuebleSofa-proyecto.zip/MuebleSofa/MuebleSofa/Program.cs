﻿using System;


class PruebaMuebleSofa
{
    static void Main()
    {
        Mueble m = new Mueble("s1", "Silla", "Metal");
        Sofa s = new Sofa("sofa01", "Sofa Hector");

        Console.WriteLine(m);
        Console.WriteLine(s);
    }
}
