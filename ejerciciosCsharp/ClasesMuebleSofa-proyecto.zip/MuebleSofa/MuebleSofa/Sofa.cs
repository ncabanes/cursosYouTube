﻿using System;

class Sofa : Mueble
{
    protected byte plazas;

    public Sofa(string codigo, string descripcion, string material,
        byte plazas) : base(codigo, descripcion, material)
    {
        this.plazas = plazas;
    }

    public Sofa(string codigo, string descripcion) 
        : this(codigo, descripcion, "Madera y textil", 3)
    {
    }

    public byte Plazas
    {
        get { return plazas; }
    }

    public override string ToString()
    {
        return base.ToString() + " Sofá de " + plazas + " plazas";
    }
}

