﻿/*
Crea un programa en C# que se pueda utilizar para guardar información sobre 
lenguajes de programación. Para lenguajes, se debe poder almacenar la siguiente 
información:

-  Nombre (por ejemplo, Java)

-  Año de creación (por ejemplo, 1996)

Además, deseamos distinguir dos tipos de lenguajes, con información adicional 
para cada uno de ellos:

-  Imperativos (con un dato adicional que indique si es orientado a objetos o no)

-  Declarativos (con un dato adicional de tipo texto, que indique qué subtipo 
   concreto de lenguaje es: lógico, funcional, matemático o reactivo).

No querremos guardar lenguajes que no pertenezcan a uno de estos dos tipos. 
Para los imperativos, se deberán indicar todos los atributos en el constructor. 
Para los declarativos, existirán dos constructores: uno que reciba todos los 
atributos y otro que prefije a "funcional" el subtipo de lenguaje.

El programa debe permitir al usuario realizar las siguientes operaciones:

1 - Añadir un nuevo lenguaje de programación.

2 - Mostrar todos los lenguajes (número de registro, nombre, año, tipo y demás 
detalles adicionales), haciendo una pausa tras cada 24 filas. Deberás ayudarte 
de métodos "ToString()".

3 - Buscar lenguajes que contengan un texto determinado. La búsqueda parcial 
será parcial en el nombre y (según el caso) en el subtipo, pero exacta en el 
año (por ejemplo, para el texto "ja" sí se mostrarán los datos de Java, pero no 
para la búsqueda "96").

4 - Modificar un lenguaje. Se pedirá al usuario su número, se mostrará el valor 
anterior de cada campo y podrá pulsar Intro sin escribir nada, si opta por no 
modificar algún campo. Se le avisará (pero no se le volverá a pedir) si 
introduce un número de registro incorrecto.

5 - Eliminar un lenguaje, en la posición detallada por el usuario. Se debe 
avisar (pero no volver a preguntar) si introduce un número de registro 
incorrecto. Deberá mostrar el registro que se eliminará y solicitar 
confirmación antes de la eliminación.

6 - Ordenar los datos alfabéticamente, por nombre del lenguaje.

7 – Resumen por categorías. Mostrará todos los datos de lenguajes 
procedimentales (no orientados a objetos), luego los orientados a objeto, y 
finalmente cada uno de los subtipos de lenguajes declarativos (por ejemplo, 
todos los funcionales, luego todos los lógicos, etc., teniendo en cuenta que, 
al ser un campo de texto, quizá el usuario haya introducido algún otro tipo "no 
tan estándar", como por ejemplo "de marcado" o "de consulta de bases de 
datos"). Todos los lenguajes de un subtipo (por ejemplo, todos los funcionales) 
deben aparecer juntos, agrupados. 

T - Terminar.
*/

using System;


class EjercicioLenguajes
{
    static void Main(string[] args)
    {
        GestorDeLenguajes gestor = new GestorDeLenguajes();
        gestor.Ejecutar();
    }
}
