﻿using System;

abstract class Lenguaje : IComparable<Lenguaje>
{
    public string Nombre { get; set; }
    public ushort Anyo { get; set; }

    public Lenguaje(string nombre, int anyo)
    {
        Nombre = nombre;
        Anyo = (ushort)anyo;
    }

    public override string ToString()
    {
        return Nombre + " - " + "(" + Anyo + ")";
    }

    public int CompareTo(Lenguaje l)
    {
        return String.Compare(Nombre, l.Nombre, true);
    }

    public virtual bool Contiene(string texto)
    {
        if (Nombre.ToLower().Contains(texto.ToLower()) 
                || Anyo.ToString() == texto)
            return true;
        else
            return false;
    }
}
