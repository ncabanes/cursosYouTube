﻿class Declarativo : Lenguaje
{
    public string Subtipo { get; set; }

    public Declarativo(string nombre, int anyo, string subtipo)
        : base(nombre, anyo)
    {
        Subtipo = subtipo;
    }

    public Declarativo(string nombre, int anyo)
        : this(nombre, anyo, "funcional")
    {
    }

    public override string ToString()
    {
        return base.ToString() + " Declarativo " + Subtipo;
    }

    public override bool Contiene(string texto)
    {
        if (base.Contiene(texto) ||
                Subtipo.ToLower().Contains(texto.ToLower()))
            return true;
        else
            return false;
    }
}
