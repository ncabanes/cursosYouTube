﻿class Imperativo : Lenguaje
{
    public bool OrientadoObjetos { get; set; }

    public Imperativo(string nombre, int anyo, bool orientadoObjetos)
        : base(nombre, anyo)
    {
        OrientadoObjetos = orientadoObjetos;
    }

    public override string ToString()
    {
        string texto = base.ToString() + " Imperativo";
        if (OrientadoObjetos)
            texto += " Orientado a Objetos";
        else
            texto += " No orientado a objetos";

        return texto;
    }
}
