﻿using System;
using System.Collections.Generic;

class GestorDeLenguajes
{
    public void Ejecutar()
    {
        List<Lenguaje> lenguajes = new List<Lenguaje>();
        bool salir = false;

        do
        {
            MostrarMenu();
            string opcion = Console.ReadLine().ToUpper();
            switch (opcion)
            {
                case "1": Anyadir(lenguajes); break;
                case "2": Mostrar(lenguajes); break;
                case "3": Buscar(lenguajes); break;
                case "4": Modificar(lenguajes); break;
                case "5": Eliminar(lenguajes); break;
                case "6": Ordenar(lenguajes); break;
                case "7": MostrarResumen(lenguajes); break;
                case "T": salir = true; break;
                default: AvisarOpcionIncorrecta(); break;
            }
        }
        while (!salir);
        Console.WriteLine("Hasta la próxima!");
    }

    private void MostrarMenu()
    {
        Console.WriteLine();
        Console.WriteLine("1. Añadir nuevo lenguaje");
        Console.WriteLine("2. Mostrar todos los leguajes");
        Console.WriteLine("3. Buscar leguajes por texto");
        Console.WriteLine("4. Modificar lenguaje");
        Console.WriteLine("5. Eliminar leguaje");
        Console.WriteLine("6. Ordenar alfabéticamente por nombre");
        Console.WriteLine("7. Resumen por categorías");
        Console.WriteLine("T. Terminar");
        Console.WriteLine();
    }

    private void Anyadir(List<Lenguaje> lenguajes)
    {
        string nombre = PedirDato("nombre");
        int anyo = Convert.ToInt32(PedirDato("año de creación"));
        string tipoLenguaje = PedirDato("tipo de lenguaje (i) Imperativo o " +
            "(d) Declarativo").ToLower();
        switch (tipoLenguaje)
        {
            case "i":
                string orientadoObjetos = PedirDato(
                    "¿es orientado a objeto? (s/n)").ToLower();
                if (orientadoObjetos == "s")
                    lenguajes.Add(new Imperativo(nombre, anyo, true));
                else
                    lenguajes.Add(new Imperativo(nombre, anyo, false));
                break;

            case "d":
                string subtipo = PedirDato(
                    "subtipo o Intro para \"funcional\"");
                if (subtipo == "")
                    lenguajes.Add(new Declarativo(nombre, anyo));
                else
                    lenguajes.Add(new Declarativo(nombre, anyo, subtipo));
                break;

            default: AvisarOpcionIncorrecta(); break;
        }
    }

    private void Mostrar(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            for (int i = 0; i < lenguajes.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + lenguajes[i]);
                if (i % 24 == 23)
                {
                    Console.Write("Pulsa Intro para continuar... ");
                    Console.ReadLine();
                }
            }
        }
        else
        {
            AvisarListaVacia();
        }
    }

    private void Buscar(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            bool encontrado = false;
            string textoBuscar = PedirDato("texto de búsqueda").ToLower();

            for (int i = 0; i < lenguajes.Count; i++)
            {
                if (lenguajes[i].Contiene(textoBuscar))
                {
                    Console.WriteLine((i + 1) + ". " + lenguajes[i]);
                    encontrado = true;
                }
            }

            if (!encontrado)
                Console.WriteLine("No se han encontrado coincidencias");
        }
        else
            AvisarListaVacia();
    }

    private void Modificar(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            int registro = Convert.ToInt32(
                PedirDato("registro a modificar")) - 1;
            if (registro >= 0 && registro < lenguajes.Count)
            {
                Console.WriteLine("Nombre: " + lenguajes[registro].Nombre);
                string nombre = PedirDato("nombre o Intro para continuar");
                if (nombre != "")
                    lenguajes[registro].Nombre = nombre;

                Console.WriteLine("Año de creacion: " +
                    lenguajes[registro].Anyo);
                string anyo = PedirDato("Año de creación o Intro " +
                    "para continuar");
                if (anyo != "")
                    lenguajes[registro].Anyo =
                        Convert.ToUInt16(anyo);

                if (lenguajes[registro] is Imperativo)
                {
                    Console.WriteLine("Orientado a objetos: " +
                        ((Imperativo)lenguajes[registro]).OrientadoObjetos);
                    string orientadoObjetos = PedirDato("Orientado a Objetos " +
                        "(s/n) o Intro para continuar").ToLower();

                    if (orientadoObjetos == "s")
                        ((Imperativo)lenguajes[registro]).OrientadoObjetos = true;
                    else if (orientadoObjetos == "n")
                        ((Imperativo)lenguajes[registro]).OrientadoObjetos = false;
                }

                if (lenguajes[registro] is Declarativo)
                {
                    string subtipo = PedirDato("subtipo o Intro para continuar");
                    if (subtipo != "")
                        ((Declarativo)lenguajes[registro]).Subtipo = subtipo;
                }
            }
            else
                AvisarRegistroIncorrecto();
        }
        else
            AvisarListaVacia();
    }

    private void Eliminar(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            int registro = Convert.ToInt32(
                PedirDato("registro a borrar")) - 1;
            if (registro >= 0 && registro < lenguajes.Count)
            {
                Console.WriteLine(lenguajes[registro]);
                string confirmacion = PedirDato("(s) confirmar o Intro para" +
                    " cancelar").ToLower();
                if (confirmacion == "s")
                {
                    lenguajes.RemoveAt(registro);
                    Console.WriteLine("Registro eliminado");
                }
                else
                    Console.WriteLine("Borrado cancelado");
            }
            else
                AvisarRegistroIncorrecto();
        }
        else
            AvisarListaVacia();
    }

    private void Ordenar(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            lenguajes.Sort();
            Console.WriteLine("Registro ordenados");
        }
        else
            AvisarListaVacia();
    }

    private void MostrarResumen(List<Lenguaje> lenguajes)
    {
        if (lenguajes.Count > 0)
        {
            for (int i = 0; i < lenguajes.Count; i++)
            {
                if ((lenguajes[i] is Imperativo) &&
                        (!((Imperativo)lenguajes[i]).OrientadoObjetos))
                    Console.WriteLine(lenguajes[i]);
            }

            for (int i = 0; i < lenguajes.Count; i++)
            {
                if ((lenguajes[i] is Imperativo) &&
                        ((Imperativo)lenguajes[i]).OrientadoObjetos)
                    Console.WriteLine(lenguajes[i]);
            }

            // Primero busco los tipos de lenguajes que se han usado
            List<string> tiposLenguajes = new List<string>();
            for (int i = 0; i < lenguajes.Count; i++)
            {
                if (lenguajes[i] is Declarativo)
                {
                    if (!tiposLenguajes.Contains(
                            ((Declarativo)(lenguajes[i])).Subtipo))
                        tiposLenguajes.Add(
                            ((Declarativo)(lenguajes[i])).Subtipo);
                }
            }
            // Luego ordeno
            tiposLenguajes.Sort();

            // Y finalmente muestro, en orden, los datos de todos ellos
            for (int t = 0; t < tiposLenguajes.Count; t++)
            {
                for (int i = 0; i < lenguajes.Count; i++)
                {
                    if (lenguajes[i] is Declarativo)
                    {
                        if (((Declarativo)lenguajes[i]).Subtipo == tiposLenguajes[t])
                            Console.WriteLine(lenguajes[i]);
                    }
                }
            }

        }
        else
            AvisarListaVacia();
    }

    private string PedirDato(string aviso)
    {
        Console.Write("Introduce " + aviso + ": ");
        return Console.ReadLine();
    }

    private void AvisarOpcionIncorrecta()
    {
        Console.WriteLine("Opción incorrecta");
    }

    private void AvisarListaVacia()
    {
        Console.WriteLine("No hay datos almacenados");
    }

    private void AvisarRegistroIncorrecto()
    {
        Console.WriteLine("Número de registro incorrecto");
    }
}
