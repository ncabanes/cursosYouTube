﻿class BloqueDeEnemigos
{
}
