﻿class ListaDeDisparos
{
}
