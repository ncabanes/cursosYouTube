﻿class Disparo
{
}
