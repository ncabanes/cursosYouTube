﻿class PantallaCreditos
{
}
