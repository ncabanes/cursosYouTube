﻿class Partida
{
    bool partidaTerminada;
    Jugador nave;
    Enemigo enemigo;

    public void Lanzar()
    {
        InicializarPartida();
        while (!partidaTerminada)
        {
            DibujarPantalla();
            ComprobarEntradaUsuario();
            AnimarElementos();
            ComprobarEstadoDelJuego();
            PausaHastaFinDeFotograma();
        }
    }

    private void InicializarPartida()
    {
        partidaTerminada = false;
        nave = new Jugador();
        enemigo = new Enemigo();
    }

    private void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();
        enemigo.Dibujar();
        nave.Dibujar();
        Hardware.VisualizarOculta();
    }

    private void ComprobarEntradaUsuario()
    {
        if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
            nave.MoverDerecha();
        if (Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
            nave.MoverIzquierda();

        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            partidaTerminada = true;
    }

    private void AnimarElementos()
    {
        enemigo.Mover();
    }

    private void ComprobarEstadoDelJuego()
    {
        if (nave.ColisionaCon(enemigo))
            partidaTerminada = true;
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }
}
