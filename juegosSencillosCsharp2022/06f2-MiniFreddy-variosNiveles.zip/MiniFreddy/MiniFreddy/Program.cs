﻿using System;

class MiniFreddy
{
    static bool partidaTerminada;
    static bool sesionTerminada;
    static Sprite personaje;
    static Sprite enemigo;
    static Sprite[] items;
    static Sprite[,] paredes;
    static int x, y;
    static int xEnemigo, yEnemigo;
    static int velocEnemigo;
    static int cantidadItems, itemsRestantes;
    static int puntos;
    static int fotogramasRestantes;
    static Fuente tipoDeLetra;
    static Fuente tipoDeLetraGrande;

    static string[,] mapa =
    {
        {
            "############@@###########",
            "#        #       #      #",
            "#                       #",
            "#        #              #",
            "#        #              #",
            "#            #          #",
            "#                       #",
            "#                       #",
            "#                       #",
            "#########################",
        },
        {
            "############@@###########",
            "#        #       #      #",
            "# ###                   #",
            "#        #          ### #",
            "#        #              #",
            "#            #          #",
            "#####              ##   #",
            "#      #@@#             #",
            "#                       #",
            "#########################",
        },
    };
    static int xMapa, yMapa;
    static int anchoTile, altoTile;
    static int cantidadNiveles, anchoMapa, altoMapa;
    static int nivelActual = 0;
    static Sonido sonidoRecoger;
    static Random generador;

    static void Main(string[] args)
    {
        InicializarSesion();
        do
        {
            MostrarPantallaBienvenida();

            if (!sesionTerminada)
            {
                InicializarPartida();

                while (!partidaTerminada)
                {
                    DibujarPantalla();
                    ComprobarEntradaUsuario();
                    AnimarElementos();
                    ComprobarEstadoDelJuego();
                    PausaHastaFinDeFotograma();
                }
            }
        }
        while (!sesionTerminada);
    }

    private static void InicializarSesion()
    {
        Hardware.Inicializar(1280, 720, 24);
        sesionTerminada = false;

        tipoDeLetra = new Fuente("datos\\FreeSansBold.ttf", 18);
        tipoDeLetraGrande = new Fuente("datos\\joystix.ttf", 48);

        cantidadNiveles = mapa.GetLength(0);
        altoMapa = mapa.GetLength(1);
        anchoMapa = mapa[0, 0].Length;
    }

    private static void MostrarPantallaBienvenida()
    {
        bool bienvenidaTerminada = false;
        Hardware.BorrarPantallaOculta();

        Hardware.EscribirTextoOculta("MINI FREDDY",
            400, 150, // Coordenadas
            200, 200, 200, // Colores
            tipoDeLetraGrande);
        Hardware.EscribirTextoOculta("Pulsa J para jugar",
            500, 350, // Coordenadas
            180, 180, 180, // Colores
            tipoDeLetra);
        Hardware.EscribirTextoOculta("Pulsa T para terminar",
            500, 400, // Coordenadas
            160, 160, 160, // Colores
            tipoDeLetra);

        Hardware.VisualizarOculta();

        do
        {
            Hardware.Pausa(20);
            if (Hardware.TeclaPulsada(Hardware.TECLA_T))
            {
                bienvenidaTerminada = true;
                sesionTerminada = true;
            }
            if (Hardware.TeclaPulsada(Hardware.TECLA_J))
            {
                bienvenidaTerminada = true;
            }
        }
        while (!bienvenidaTerminada);

    }

    private static void InicializarPartida()
    {
        generador = new Random();
        
        personaje = new Sprite("datos\\personaje.png");
        personaje.CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\personajeDer1.png", 
                "datos\\personajeDer2.png" });
        personaje.CargarSecuencia(Sprite.IZQUIERDA,
            new string[] { "datos\\personajeIzq1.png",
                "datos\\personajeIzq2.png" });
        personaje.CambiarDireccion(Sprite.DERECHA);
        personaje.SetAnchoAlto(48, 45);

        enemigo = new Sprite("datos\\enemigo.png");
        enemigo.CargarSecuencia(Sprite.ABAJO,
            new string[] { "datos\\enemigo.png",
                "datos\\enemigo2.png" });
        enemigo.CambiarDireccion(Sprite.ABAJO);
        enemigo.SetAnchoAlto(54, 60);
        xEnemigo = 120;
        yEnemigo = 50;
        velocEnemigo = 5;

        partidaTerminada = false;
        puntos = 0;

        xMapa = 30; yMapa = 100;
        anchoTile = 48; altoTile = 60;

        nivelActual = -1;
        AvanzarNivel();

        fotogramasRestantes = 10;
        sonidoRecoger = new Sonido("datos\\recogido.mp3");
    }

    private static void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();

        for (int fila = 0; fila < altoMapa; fila++)
        {
            for (int columna = 0; columna < anchoMapa; columna++)
            {
                if (paredes[fila, columna] != null)
                    paredes[fila, columna].Dibujar();
            }
        }

        Hardware.EscribirTextoOculta(
            "Puntos " + puntos,
            10, 10,
            255, 0, 0,
            tipoDeLetra);

        enemigo.MoverA(xEnemigo, yEnemigo);
        enemigo.Dibujar();

        for (int i = 0; i < cantidadItems; i++)
        {
            items[i].Dibujar();
        }

        personaje.MoverA(x, y);
        personaje.Dibujar();

        Hardware.VisualizarOculta();
    }

    private static void ComprobarEntradaUsuario()
    {
        if ((Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
                && EsPosibleMoverA(x - 3, y, x + 48 - 3, y + 45))
        {
            x -= 3;
            personaje.CambiarDireccion(Sprite.IZQUIERDA);
            personaje.SiguienteFotograma();
        }
        if ((Hardware.TeclaPulsada(Hardware.TECLA_DER))
                && EsPosibleMoverA(x + 3, y, x + 48 + 3, y + 45))
        {
            x += 3;
            personaje.CambiarDireccion(Sprite.DERECHA);
            personaje.SiguienteFotograma();
        }
        if ((Hardware.TeclaPulsada(Hardware.TECLA_ARR))
                && EsPosibleMoverA(x, y - 3, x + 48, y + 45 - 3))
        {
            y -= 3;
            personaje.SiguienteFotograma();
        }
        if ((Hardware.TeclaPulsada(Hardware.TECLA_ABA))
                && EsPosibleMoverA(x, y + 3, x + 48, y + 45 + 3))
        {
            y += 3;
            personaje.SiguienteFotograma();
        }


        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            partidaTerminada = true;
    }

    

    private static void AnimarElementos()
    {
        if ((xEnemigo <= 100) || (xEnemigo >= 1100))
            velocEnemigo = -velocEnemigo;
        xEnemigo += velocEnemigo;
        fotogramasRestantes--;
        if (fotogramasRestantes <= 0)
        {
            fotogramasRestantes = 10;
            enemigo.SiguienteFotograma();
        }
    }

    private static void ComprobarEstadoDelJuego()
    {
        for (int i = 0; i < cantidadItems; i++)
        {
            if (items[i].ColisionaCon(personaje))
            {
                puntos += 10;
                items[i].SetActivo(false);
                sonidoRecoger.Reproducir1();

                itemsRestantes--;
                if (itemsRestantes <= 0)
                    AvanzarNivel();
            }
        }

        if (personaje.ColisionaCon(enemigo))
            partidaTerminada = true;
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }

    private static bool EsPosibleMoverA(
        int xIni, int yIni, int xFin, int yFin)
    {
        for (int fila = 0; fila < altoMapa; fila++)
        {
            for (int columna = 0; columna < anchoMapa; columna++)
            {
                if (paredes[fila, columna] != null)
                {
                    if (paredes[fila, columna].ColisionaCon(
                            xIni, yIni, xFin, yFin))
                        return false;
                }
            }
        }
        return true;
    }

    private static void AvanzarNivel()
    {
        x = 600;
        y = 300;

        nivelActual++;
        if (nivelActual >= cantidadNiveles)
            nivelActual = 0;

        paredes = new Sprite[mapa.Length, mapa[nivelActual, 0].Length];
        for (int fila = 0; fila < altoMapa; fila++)
        {
            for (int columna = 0; columna < anchoMapa; columna++)
            {
                if ((mapa[nivelActual, fila][columna] == '#')
                    || (mapa[nivelActual, fila][columna] == '@'))
                {
                    if (mapa[nivelActual, fila][columna] == '#')
                        paredes[fila, columna] = new Sprite("datos\\ladrillo.png");
                    else
                        paredes[fila, columna] = new Sprite("datos\\ladrillo2.png");

                    paredes[fila, columna].MoverA(
                        xMapa + columna * anchoTile,
                        yMapa + fila * altoTile);
                    paredes[fila, columna].SetAnchoAlto(anchoTile, altoTile);
                }
            }
        }

        cantidadItems = 20;
        itemsRestantes = cantidadItems;
        items = new Sprite[cantidadItems];
        for (int i = 0; i < cantidadItems; i++)
        {
            bool posicionValida = false;
            do
            {
                int xPared = generador.Next(100, 1100);
                int yPared = generador.Next(100, 600);
                posicionValida = EsPosibleMoverA(xPared, yPared,
                    xPared + 60, yPared + 18);
                if (posicionValida)
                {
                    items[i] = new Sprite("datos\\item1.png");
                    items[i].MoverA(xPared, yPared);
                    items[i].SetAnchoAlto(60, 18);
                }
            }
            while (!posicionValida);
        }
    }
}

