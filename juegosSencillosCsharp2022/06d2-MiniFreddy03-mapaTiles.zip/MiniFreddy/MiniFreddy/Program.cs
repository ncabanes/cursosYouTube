﻿using System;

class MiniFreddy
{
    static bool terminado;
    static Sprite personaje;
    static Sprite enemigo;
    static Sprite[] items;
    static Sprite[,] paredes;
    static int x, y;
    static int xEnemigo, yEnemigo;
    static int velocEnemigo;
    static int cantidadItems;
    static int puntos;
    static Fuente tipoDeLetra;

    static string[] mapa =
    {
        "############@@###########",
        "#        #       #      #",
        "#                       #",
        "#        #              #",
        "#        #              #",
    };
    static int xMapa, yMapa;
    static int anchoTile, altoTile;

    static void Main(string[] args)
    {
        InicializarJuego();

        while (!terminado)
        {
            DibujarPantalla();
            ComprobarEntradaUsuario();
            AnimarElementos();
            ComprobarEstadoDelJuego();
            PausaHastaFinDeFotograma();
        }
    }
    private static void InicializarJuego()
    {
        Random generador = new Random();
        Hardware.Inicializar(1280, 720, 24);
        personaje = new Sprite("datos\\personaje.png");
        personaje.SetAnchoAlto(48, 45);
        x = 600;
        y = 300;

        enemigo = new Sprite("datos\\enemigo.png");
        enemigo.SetAnchoAlto(54, 60);
        xEnemigo = 120;
        yEnemigo = 50;
        velocEnemigo = 5;

        cantidadItems = 20;
        items = new Sprite[cantidadItems];
        for (int i = 0; i < cantidadItems; i++)
        {
            items[i] = new Sprite("datos\\item1.png");
            items[i].MoverA(
                generador.Next(100, 1100),
                generador.Next(100, 600));
            items[i].SetAnchoAlto(60, 18);
        }

        tipoDeLetra = new Fuente("datos\\FreeSansBold.ttf", 18);
        terminado = false;
        puntos = 0;

        xMapa = 30; yMapa = 100;
        anchoTile = 48; altoTile = 60;

        paredes = new Sprite[mapa.Length, mapa[0].Length];
        for (int fila = 0; fila < mapa.Length; fila++)
        {
            for (int columna = 0; columna < mapa[0].Length; columna++)
            {
                if ((mapa[fila][columna] == '#')
                    || (mapa[fila][columna] == '@'))
                {
                    if (mapa[fila][columna] == '#')
                        paredes[fila, columna] = new Sprite("datos\\ladrillo.png");
                    else
                        paredes[fila, columna] = new Sprite("datos\\ladrillo2.png");

                    paredes[fila, columna].MoverA(
                        xMapa + columna * anchoTile,
                        yMapa + fila * altoTile);
                    paredes[fila, columna].SetAnchoAlto(anchoTile, altoTile);
                }
            }
        }
    }

    private static void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();

        for (int fila = 0; fila < mapa.Length; fila++)
        {
            for (int columna = 0; columna < mapa[0].Length; columna++)
            {
                if (paredes[fila, columna] != null)
                    paredes[fila, columna].Dibujar();
            }
        }

        Hardware.EscribirTextoOculta(
            "Puntos " + puntos,
            10, 10,
            255, 0, 0,
            tipoDeLetra);

        enemigo.MoverA(xEnemigo, yEnemigo);
        enemigo.Dibujar();

        for (int i = 0; i < cantidadItems; i++)
        {
            items[i].Dibujar();
        }

        personaje.MoverA(x, y);
        personaje.Dibujar();

        Hardware.VisualizarOculta();
    }

    private static void ComprobarEntradaUsuario()
    {
        if ((Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
                && EsPosibleMoverA(x-3, y, x+48-3, y+45))
            x -= 3;
        if ((Hardware.TeclaPulsada(Hardware.TECLA_DER))
                && EsPosibleMoverA(x + 3, y, x + 48 + 3, y + 45))
            x += 3;
        if ((Hardware.TeclaPulsada(Hardware.TECLA_ARR))
                && EsPosibleMoverA(x, y-3, x + 48, y + 45-3))
            y -= 3;
        if ((Hardware.TeclaPulsada(Hardware.TECLA_ABA))
                && EsPosibleMoverA(x, y+3, x + 48, y + 45 + 3))
            y += 3;


        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            terminado = true;
    }

    

    private static void AnimarElementos()
    {
        if ((xEnemigo <= 100) || (xEnemigo >= 1100))
            velocEnemigo = -velocEnemigo;
        xEnemigo += velocEnemigo;
    }

    private static void ComprobarEstadoDelJuego()
    {
        for (int i = 0; i < cantidadItems; i++)
        {
            if (items[i].ColisionaCon(personaje))
            {
                puntos += 10;
                items[i].SetActivo(false);
            }
        }

        if (personaje.ColisionaCon(enemigo))
            terminado = true;
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }

    private static bool EsPosibleMoverA(
        int xIni, int yIni, int xFin, int yFin)
    {
        for (int fila = 0; fila < mapa.Length; fila++)
        {
            for (int columna = 0; columna < mapa[0].Length; columna++)
            {
                if (paredes[fila, columna] != null)
                {
                    if (paredes[fila, columna].ColisionaCon(
                            xIni, yIni, xFin, yFin))
                        return false;
                }
            }
        }
        return true;
    }
}

