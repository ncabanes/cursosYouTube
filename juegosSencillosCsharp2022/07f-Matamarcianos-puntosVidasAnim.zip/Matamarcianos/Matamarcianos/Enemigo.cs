﻿class Enemigo : Sprite
{
    public Enemigo()
        : base("datos\\enemigo1a.png")
    {
        ancho = 48;
        alto = 24;
        x = 640;
        y = 100;
        velocX = 5;
        velocY = 0;

        CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\enemigo1a.png",
                "datos\\enemigo1b.png" });
        CambiarDireccion(Sprite.DERECHA);

        SetFramesPorFotograma(12);
    }

    public override void Mover()
    {
        x += velocX;
        y += velocY;

        SiguienteFotograma();

        /*
        if ((x <= 100) || (x >= 1100))
            velocX = -velocX;

        if ((y <= 20) || (y >= 680))
            velocY = -velocY;
        */
    }
}
