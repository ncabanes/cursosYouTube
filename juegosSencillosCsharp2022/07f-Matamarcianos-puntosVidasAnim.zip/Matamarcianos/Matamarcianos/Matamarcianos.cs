﻿
class Matamarcianos
{
    static void Main(string[] args)
    {
        Hardware.Inicializar(1280, 720, 24);

        Partida partida = new Partida();
        partida.Lanzar();
    }
}

