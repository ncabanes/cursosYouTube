﻿using System;
using System.Collections.Generic;

class ListaDeDisparos
{
    List<Disparo> disparos;
    int maxDisparos;
    DateTime instanteUltimoDisparo;
    float milisegundosEntreDisparos;

    public ListaDeDisparos()
    {
        disparos = new List<Disparo>();
        maxDisparos = 3;
        instanteUltimoDisparo = DateTime.Now;
        milisegundosEntreDisparos = 200;
    }

    public void IntentarAnadir(int x, int y)
    {
        if ((DateTime.Now - instanteUltimoDisparo).Milliseconds 
                < milisegundosEntreDisparos)
            return;

        if (disparos.Count >= maxDisparos)
            return;

        Disparo d = new Disparo();
        d.Activar(x, y);
        disparos.Add(d);
        instanteUltimoDisparo = DateTime.Now;
    }

    public void Dibujar()
    {
        foreach (Disparo e in disparos)
        {
            e.Dibujar();
        }
    }

    public void Mover(BloqueDeEnemigos be)
    {
        foreach (Disparo d in disparos)
        {
            d.Mover();
            if (be.ColisionaCon(d))
                d.SetActivo(false);
        }

        for (int i = 0; i < disparos.Count; i++)
        {
            if (! disparos[i].GetActivo() )
            {
                disparos.RemoveAt(i);
                i--;
            }
        }
    }
}
