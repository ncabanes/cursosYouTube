﻿class Disparo : Sprite
{
    public Disparo()
    : base("datos\\disparo.png")
    {
        ancho = 6;
        alto = 15;
        velocX = 0;
        velocY = -5;
        activo = false;
    }

    public void Activar(int x, int y)
    {
        this.x = x;
        this.y = y;
        activo = true;
    }

    public override void Mover()
    {
        y += velocY;

        if (y <= 0)
            activo = false;
    }
}
