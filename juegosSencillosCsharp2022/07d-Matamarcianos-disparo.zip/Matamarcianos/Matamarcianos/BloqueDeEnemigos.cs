﻿using System.Collections.Generic;

class BloqueDeEnemigos
{
    List<Enemigo> enemigos;
    int velocidadBloque;

    public BloqueDeEnemigos()
    {
        velocidadBloque = 5;
        enemigos = new List<Enemigo>();
        for (int fila = 0; fila < 4; fila++)
        {
            for (int columna = 0; columna < 6; columna++)
            {
                Enemigo e = new Enemigo();
                e.MoverA(columna * 150 + 150, fila * 100 + 20);
                e.SetVelocidad(5, 0);
                enemigos.Add(e);
            }
        }
    }

    public void Dibujar()
    {
        foreach (Enemigo e in enemigos)
        {
            e.Dibujar();
        }
    }

    public void Mover()
    {
        foreach (Enemigo e in enemigos)
        {
            e.Mover();
        }

        foreach (Enemigo e in enemigos)
        {
            if ((e.GetActivo()) && (e.GetX() > 1100))
                velocidadBloque = -5;

            if ((e.GetActivo()) && (e.GetX() < 100))
                velocidadBloque = 5;
        }

        foreach (Enemigo e in enemigos)
        {
            e.SetVelocidad(velocidadBloque, 0);
        }

    }

    public bool ColisionaCon(Sprite s)
    {
        foreach (Enemigo e in enemigos)
        {
            if (s.ColisionaCon(e))
            {
                e.SetActivo(false);
                return true;
            }
        }
        return false;
    }
}
