﻿class Marcador
{
}
