﻿using System;
using System.Threading;
using Tao.Sdl;


class PruebaSDL
{
    static void Main(string[] args)
    {
        IntPtr pantallaOculta;
        IntPtr imagen;
        short x = 600;
        short y = 320;

        int ancho = 1280;
        int alto = 720;
        int bitsColor = 24;
        int flags = Sdl.SDL_DOUBLEBUF | Sdl.SDL_HWSURFACE
            | Sdl.SDL_ANYFORMAT;

        Sdl.SDL_Init(Sdl.SDL_INIT_EVERYTHING);


        pantallaOculta = Sdl.SDL_SetVideoMode(ancho, alto,
            bitsColor, flags);

        Sdl.SDL_Rect recorte =
            new Sdl.SDL_Rect(0, 0, (short) ancho, (short) alto);
        Sdl.SDL_SetClipRect(pantallaOculta, ref recorte);

        
        imagen = Sdl.SDL_LoadBMP("personaje.bmp");
        if (imagen == IntPtr.Zero)
        {
            Console.WriteLine("No se ha podido cargar");
            Environment.Exit(1);
        }

        Sdl.SDL_Rect origen = new Sdl.SDL_Rect(0, 0, 48, 45);
        Sdl.SDL_Rect destino = new Sdl.SDL_Rect(x, y, 48, 45);
        Sdl.SDL_BlitSurface(imagen, ref origen, pantallaOculta, ref destino);

        Sdl.SDL_Flip(pantallaOculta);

        Thread.Sleep(5000);

        Sdl.SDL_Quit();
    }
}
