﻿class Partida
{
    bool partidaTerminada;
    Jugador nave;
    BloqueDeEnemigos enemigos;
    ListaDeDisparos disparos;
    ListaDeDisparosEnemigos disparosE;
    int puntos;
    int vidas;
    Marcador marcador;

    public Partida()
    {
        partidaTerminada = false;
        nave = new Jugador();
        enemigos = new BloqueDeEnemigos();
        disparos = new ListaDeDisparos();
        disparosE = new ListaDeDisparosEnemigos();
        marcador = new Marcador();
        puntos = 0;
        vidas = 3;
    }

    public void Lanzar()
    {
        while (!partidaTerminada)
        {
            DibujarPantalla();
            ComprobarEntradaUsuario();
            AnimarElementos();
            ComprobarEstadoDelJuego();
            PausaHastaFinDeFotograma();
        }
    }

    

    private void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();
        marcador.Dibujar();
        enemigos.Dibujar();
        nave.Dibujar();
        disparos.Dibujar();
        disparosE.Dibujar();
        Hardware.VisualizarOculta();
    }

    private void ComprobarEntradaUsuario()
    {
        if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
            nave.MoverDerecha();
        if (Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
            nave.MoverIzquierda();
        if (Hardware.TeclaPulsada(Hardware.TECLA_ESP))
            disparos.IntentarAnadir(nave.GetX()+20, nave.GetY()-15);

        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            partidaTerminada = true;
    }

    private void AnimarElementos()
    {
        enemigos.Mover();
        disparos.Mover(enemigos, this);
        disparosE.Mover(enemigos);
    }

    private void ComprobarEstadoDelJuego()
    {
        if (enemigos.ColisionaCon(nave))
            PerderVida();

        if (disparosE.ColisionaCon(nave))
            PerderVida();
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }

    public void IncrementarPuntos(int puntos)
    {
        this.puntos += puntos;
        marcador.SetPuntos(this.puntos);
    }

    private void PerderVida()
    {
        vidas--;
        marcador.SetVidas(vidas);
        nave.MoverA(640, 600);
        disparosE.Vaciar();
        if (vidas <= 0)
            partidaTerminada = true;
    }
}
