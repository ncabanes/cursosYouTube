﻿
class Jugador : Sprite
{

    public Jugador()
        : base("datos//jugador.png")
    {
        ancho = 54;
        alto = 57;
        x = 640;
        y = 600;
        velocX = 5;

        CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\jugador.png",
                "datos\\jugador2.png" });
        CambiarDireccion(Sprite.DERECHA);
        SetFramesPorFotograma(20);
    }

    public void MoverDerecha()
    {
        x += velocX;
        SiguienteFotograma();
    }

    public void MoverIzquierda()
    {
        x -= velocX;
        SiguienteFotograma();
    }
}

