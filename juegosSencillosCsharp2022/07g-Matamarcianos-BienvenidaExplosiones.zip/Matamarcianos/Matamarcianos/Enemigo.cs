﻿class Enemigo : Sprite
{
    private int framesHastaDesaparecer;
    public Enemigo()
        : base("datos\\enemigo1a.png")
    {
        ancho = 48;
        alto = 24;
        x = 640;
        y = 100;
        velocX = 5;
        velocY = 0;
        framesHastaDesaparecer = 50;

        CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\enemigo1a.png",
                "datos\\enemigo1b.png" });
        CambiarDireccion(Sprite.DERECHA);
        CargarSecuencia(Sprite.EXPLOTANDO,
            new string[] { "datos\\enemigoE1.png",
                "datos\\enemigoE2.png" });

        SetFramesPorFotograma(12);
    }

    public override void Mover()
    {
        SiguienteFotograma();

        if (direccion == Sprite.EXPLOTANDO)
        {
            framesHastaDesaparecer--;
            if (framesHastaDesaparecer <= 0)
            {
                visible = false;
            }
        }
        if (!activo)
            return;

        x += velocX;
        y += velocY;

        

        /*
        if ((x <= 100) || (x >= 1100))
            velocX = -velocX;

        if ((y <= 20) || (y >= 680))
            velocY = -velocY;
        */
    }
}
