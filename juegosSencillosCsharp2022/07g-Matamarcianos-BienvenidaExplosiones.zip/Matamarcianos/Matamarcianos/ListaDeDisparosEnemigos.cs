﻿
using System;

class ListaDeDisparosEnemigos : ListaDeDisparos
{
    Random generador;

    public ListaDeDisparosEnemigos()
    {
        maxDisparos = 5;
        generador = new Random();
    }

    public void IntentarAnadir(int x, int y)
    {
        if ((DateTime.Now - instanteUltimoDisparo).Milliseconds
                < milisegundosEntreDisparos)
            return;

        if (disparos.Count >= maxDisparos)
            return;

        DisparoEnemigo d = new DisparoEnemigo();
        d.Activar(x, y);
        disparos.Add(d);
        instanteUltimoDisparo = DateTime.Now;
    }

    public void Mover(BloqueDeEnemigos be)
    {
        foreach (Disparo d in disparos)
        {
            d.Mover();
        }

        for (int i = 0; i < disparos.Count; i++)
        {
            if (!disparos[i].GetActivo())
            {
                disparos.RemoveAt(i);
                i--;
            }
        }

        if (disparos.Count < maxDisparos)
        {
            int numEnemigo = generador.Next(24);

            Enemigo enemigo = be.GetEnemigo(numEnemigo);
            if (enemigo.GetActivo())
            {
                IntentarAnadir(enemigo.GetX() + 20,
                    enemigo.GetY() + 15);
            }
        }
    }

    public bool ColisionaCon(Sprite s)
    {
        foreach (Disparo d in disparos)
        {
            if (s.ColisionaCon(d))
            {
                d.SetActivo(false);
                return true;
            }
        }
        return false;
    }

    public void Vaciar()
    {
        disparos.Clear();
    }
}
