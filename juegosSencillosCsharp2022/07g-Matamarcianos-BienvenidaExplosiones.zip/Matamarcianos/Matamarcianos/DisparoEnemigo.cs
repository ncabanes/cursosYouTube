﻿class DisparoEnemigo : Disparo
{
    public DisparoEnemigo()
    {
        velocY = 5;
    }
}
