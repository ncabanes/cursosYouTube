﻿
class Matamarcianos
{
    static void Main(string[] args)
    {
        Hardware.Inicializar(1280, 720, 24);

        PantallaBienvenida bienvenida = new PantallaBienvenida();
        bienvenida.Lanzar();
    }
}

