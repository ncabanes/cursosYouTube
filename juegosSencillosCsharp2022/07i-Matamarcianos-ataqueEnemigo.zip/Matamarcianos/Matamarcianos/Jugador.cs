﻿
class Jugador : Sprite
{

    public Jugador()
        : base("datos//jugador.png")
    {
        x = 640;
        y = 600;
        velocX = 5;

        CargarSecuencia(Sprite.EXPLOTANDO,
            new string[] { "datos\\jugadorE1.png",
                "datos\\jugadorE2.png" });
        CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\jugador.png",
                "datos\\jugador2.png" });
        CambiarDireccion(Sprite.DERECHA);

        ancho = 54;
        alto = 57;

        SetFramesPorFotograma(20);
    }

    public void MoverDerecha()
    {
        x += velocX;
        SiguienteFotograma();
    }

    public void MoverIzquierda()
    {
        x -= velocX;
        SiguienteFotograma();
    }

    public override void Mover()
    {
        if (direccion == Sprite.EXPLOTANDO)
        {
            SiguienteFotograma();
        }
    }

}

