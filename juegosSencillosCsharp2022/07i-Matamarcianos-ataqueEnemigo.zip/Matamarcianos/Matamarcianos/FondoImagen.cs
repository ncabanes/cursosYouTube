﻿
class FondoImagen : Sprite
{
    public FondoImagen() : base("datos\\fondoLargo.png")
    {
        y = -600;
        ancho = 960;
        alto = 1200;
    }

    public override void Mover()
    {
        y += 2;
        if (y >= 0)
        {
            y = -600;
        }
    }
}
