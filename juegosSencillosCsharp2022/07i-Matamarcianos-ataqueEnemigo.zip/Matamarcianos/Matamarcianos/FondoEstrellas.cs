﻿
using System;

class FondoEstrellas
{
    Sprite[] estrellas;
    const int NUM_ESTRELLAS = 20;

    public FondoEstrellas()
    {
        Random r = new Random();
        estrellas = new Sprite[NUM_ESTRELLAS];
        for (int i = 0; i < NUM_ESTRELLAS; i++)
        {
            estrellas[i] = new Sprite("datos\\estrella.png");
            estrellas[i].MoverA(r.Next(960), r.Next(600));
        }
    }

    public void Dibujar()
    {
        for (int i = 0; i < NUM_ESTRELLAS; i++)
        {
            estrellas[i].Dibujar();
        }
    }

    public void Mover()
    {
        for (int i = 0; i < NUM_ESTRELLAS; i++)
        {
            int x = estrellas[i].GetX();
            int y = estrellas[i].GetY();
            y += 3;
            if (y >= 600)
                y = 0;
            estrellas[i].MoverA(x, y);
        }
    }
}

