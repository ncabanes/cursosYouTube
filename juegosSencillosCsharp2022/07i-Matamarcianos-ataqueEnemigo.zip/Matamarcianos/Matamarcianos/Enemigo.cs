﻿using System;

class Enemigo : Sprite
{
    private int framesHastaDesaparecer;
    private int framesHastaAtacar;
    static Random generadorAzar;
    private bool atacando;
    private int[] desplazamientoHorizontalAtaque;
    int posicionSecuenciaAtaque;
    int xRegreso, yRegreso;

    public Enemigo(Random generador)
        : base("datos\\enemigo1a.png")
    {
        x = 640;
        y = 100;
        velocX = 5;
        velocY = 0;
        framesHastaDesaparecer = 50;
        

        CargarSecuencia(Sprite.DERECHA,
            new string[] { "datos\\enemigo1a.png",
                "datos\\enemigo1b.png" });
        CambiarDireccion(Sprite.DERECHA);
        CargarSecuencia(Sprite.EXPLOTANDO,
            new string[] { "datos\\enemigoE1.png",
                "datos\\enemigoE2.png" });

        ancho = 48;
        alto = 24;

        SetFramesPorFotograma(12);

        generadorAzar = generador;
        framesHastaAtacar = generadorAzar.Next(200, 2000);
        atacando = false;

        desplazamientoHorizontalAtaque = new int[600];
        for (int i = 0; i < 600; i++)
        {
            if (i < 200)
                desplazamientoHorizontalAtaque[i] = 2;
            else
                desplazamientoHorizontalAtaque[i] = -2;
        }
        posicionSecuenciaAtaque = 0;
    }

    public override void Mover()
    {
        SiguienteFotograma();

        if (direccion == Sprite.EXPLOTANDO)
        {
            framesHastaDesaparecer--;
            if (framesHastaDesaparecer <= 0)
            {
                visible = false;
            }
        }
        if (!activo)
            return;

        framesHastaAtacar--;
        if (framesHastaAtacar <= 0)
        {
            atacando = true;
            xRegreso = x;
            yRegreso = y;
            framesHastaAtacar = generadorAzar.Next(300, 500);
        }

        if (!atacando)
        {
            x += velocX;
            y += velocY;
        }
        else
        {
            xRegreso += velocX;

            y += 2;
            x += desplazamientoHorizontalAtaque[posicionSecuenciaAtaque];
            posicionSecuenciaAtaque++;

            if ((y > 720) || (posicionSecuenciaAtaque > 600))
            {
                atacando = false;
                posicionSecuenciaAtaque = 0;
                x = xRegreso;
                y = yRegreso;
            }
        }

        

        /*
        if ((x <= 100) || (x >= 1100))
            velocX = -velocX;

        if ((y <= 20) || (y >= 680))
            velocY = -velocY;
        */
    }
}
