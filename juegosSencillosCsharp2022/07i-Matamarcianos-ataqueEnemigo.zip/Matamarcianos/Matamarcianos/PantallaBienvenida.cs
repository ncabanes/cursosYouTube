﻿class PantallaBienvenida
{
    public void Lanzar()
    {
        bool bienvenidaTerminada = false;
        Fuente tipoDeLetra, tipoDeLetraGrande;
        tipoDeLetra = new Fuente("datos\\joystix.ttf", 18);
        tipoDeLetraGrande = new Fuente("datos\\joystix.ttf", 48);


        do
        {
            Hardware.BorrarPantallaOculta();

            Hardware.EscribirTextoOculta("MATAMARCIANOS",
                400, 150, // Coordenadas
                200, 200, 200, // Colores
                tipoDeLetraGrande);
            Hardware.EscribirTextoOculta("Pulsa J para jugar",
                500, 350, // Coordenadas
                180, 180, 180, // Colores
                tipoDeLetra);
            Hardware.EscribirTextoOculta("Pulsa C para créditos",
                500, 400, // Coordenadas
                160, 160, 160, // Colores
                tipoDeLetra);
            Hardware.EscribirTextoOculta("Pulsa T para terminar",
                500, 450, // Coordenadas
                140, 140, 140, // Colores
                tipoDeLetra);

            Hardware.VisualizarOculta();
            Hardware.Pausa(20);

            if (Hardware.TeclaPulsada(Hardware.TECLA_T))
            {
                bienvenidaTerminada = true;
            }
            if (Hardware.TeclaPulsada(Hardware.TECLA_C))
            {
                PantallaCreditos creditos = new PantallaCreditos();
                creditos.Lanzar();
            }
            if (Hardware.TeclaPulsada(Hardware.TECLA_J))
            {
                Partida partida = new Partida();
                partida.Lanzar();
            }
        }
        while (!bienvenidaTerminada);
    }
}
