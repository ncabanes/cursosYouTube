﻿
class Matamarcianos
{
    static void Main(string[] args)
    {
        Hardware.Inicializar(1280, 720, 24);
        Jugador nave = new Jugador();

        do
        {
            Hardware.BorrarPantallaOculta();
            nave.Dibujar();
            Hardware.VisualizarOculta();

            if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
                nave.MoverDerecha();
            if (Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
                nave.MoverIzquierda();

            Hardware.Pausa(20);
        }
        while (! Hardware.TeclaPulsada(Hardware.TECLA_ESC));


    }
}

