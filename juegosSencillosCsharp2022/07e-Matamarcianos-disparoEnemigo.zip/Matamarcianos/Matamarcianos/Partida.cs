﻿class Partida
{
    bool partidaTerminada;
    Jugador nave;
    BloqueDeEnemigos enemigos;
    ListaDeDisparos disparos;
    ListaDeDisparosEnemigos disparosE;

    public void Lanzar()
    {
        InicializarPartida();
        while (!partidaTerminada)
        {
            DibujarPantalla();
            ComprobarEntradaUsuario();
            AnimarElementos();
            ComprobarEstadoDelJuego();
            PausaHastaFinDeFotograma();
        }
    }

    private void InicializarPartida()
    {
        partidaTerminada = false;
        nave = new Jugador();
        enemigos = new BloqueDeEnemigos();
        disparos = new ListaDeDisparos();
        disparosE = new ListaDeDisparosEnemigos();
    }

    private void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();
        enemigos.Dibujar();
        nave.Dibujar();
        disparos.Dibujar();
        disparosE.Dibujar();
        Hardware.VisualizarOculta();
    }

    private void ComprobarEntradaUsuario()
    {
        if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
            nave.MoverDerecha();
        if (Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
            nave.MoverIzquierda();
        if (Hardware.TeclaPulsada(Hardware.TECLA_ESP))
            disparos.IntentarAnadir(nave.GetX()+20, nave.GetY()-15);

        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            partidaTerminada = true;
    }

    private void AnimarElementos()
    {
        enemigos.Mover();
        disparos.Mover(enemigos);
        disparosE.Mover(enemigos);
    }

    private void ComprobarEstadoDelJuego()
    {
        if (enemigos.ColisionaCon(nave))
            partidaTerminada = true;

        if (disparosE.ColisionaCon(nave))
            partidaTerminada = true;
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }
}
