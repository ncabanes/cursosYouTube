﻿class Marcador
{
    private int puntos;
    private int vidas;
    private static Fuente tipoDeLetra;

    public Marcador()
    {
        tipoDeLetra = new Fuente("datos\\joystix.ttf", 18);
    }

    public void SetPuntos(int puntos)
    {
        this.puntos = puntos;
    }

    public void SetVidas(int vidas)
    {
        this.vidas = vidas;
    }

    public void Dibujar()
    {
        Hardware.EscribirTextoOculta("Puntos: " + puntos,
            10, 10, // Coordenadas
            200, 200, 200, // Colores
            tipoDeLetra);
        Hardware.EscribirTextoOculta("Vidas: " + vidas,
            1150, 10, // Coordenadas
            200, 200, 200, // Colores
            tipoDeLetra);
    }



}
