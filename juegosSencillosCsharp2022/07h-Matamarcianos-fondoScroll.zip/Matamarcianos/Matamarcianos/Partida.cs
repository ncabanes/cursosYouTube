﻿class Partida
{
    bool partidaTerminada;
    Jugador nave;
    BloqueDeEnemigos enemigos;
    ListaDeDisparos disparos;
    ListaDeDisparosEnemigos disparosE;
    int puntos;
    int vidas;
    private int framesHastaDesaparecer;
    Marcador marcador;
    FondoImagen fondo1;
    FondoEstrellas fondo2;

    public Partida()
    {
        partidaTerminada = false;
        nave = new Jugador();
        enemigos = new BloqueDeEnemigos();
        disparos = new ListaDeDisparos();
        disparosE = new ListaDeDisparosEnemigos();
        marcador = new Marcador();
        fondo1 = new FondoImagen();
        fondo2 = new FondoEstrellas();
        puntos = 0;
        vidas = 3;
        framesHastaDesaparecer = 50;
    }

    public void Lanzar()
    {
        while (!partidaTerminada)
        {
            DibujarPantalla();
            ComprobarEntradaUsuario();
            AnimarElementos();
            ComprobarEstadoDelJuego();
            PausaHastaFinDeFotograma();
        }
    }

    

    private void DibujarPantalla()
    {
        Hardware.BorrarPantallaOculta();
        fondo1.Dibujar();
        fondo2.Dibujar();
        marcador.Dibujar();
        enemigos.Dibujar();
        nave.Dibujar();
        disparos.Dibujar();
        disparosE.Dibujar();
        Hardware.VisualizarOculta();
    }

    private void ComprobarEntradaUsuario()
    {
        if (Hardware.TeclaPulsada(Hardware.TECLA_DER))
            nave.MoverDerecha();
        if (Hardware.TeclaPulsada(Hardware.TECLA_IZQ))
            nave.MoverIzquierda();
        if (Hardware.TeclaPulsada(Hardware.TECLA_ESP))
            disparos.IntentarAnadir(nave.GetX()+20, nave.GetY()-15);

        if (Hardware.TeclaPulsada(Hardware.TECLA_ESC))
            partidaTerminada = true;
    }

    private void AnimarElementos()
    {
        fondo1.Mover();
        fondo2.Mover();
        enemigos.Mover();
        nave.Mover();
        disparos.Mover(enemigos, this);
        disparosE.Mover(enemigos);

        if (nave.GetDireccion() == Sprite.EXPLOTANDO)
        {
            framesHastaDesaparecer--;
            if (framesHastaDesaparecer <= 0)
            {
                disparosE.Vaciar();
                nave.MoverA(640, 600);
                if (vidas <= 0)
                    partidaTerminada = true;
                nave.SetActivo(true);
                nave.CambiarDireccion(Sprite.DERECHA);
                framesHastaDesaparecer = 50;
            }
        }

    }

    private void ComprobarEstadoDelJuego()
    {
        if (enemigos.ColisionaCon(nave))
            PerderVida();

        if (disparosE.ColisionaCon(nave))
            PerderVida();
    }

    private static void PausaHastaFinDeFotograma()
    {
        Hardware.Pausa(20);
    }

    public void IncrementarPuntos(int puntos)
    {
        this.puntos += puntos;
        marcador.SetPuntos(this.puntos);
    }

    private void PerderVida()
    {
        vidas--;
        marcador.SetVidas(vidas);
        nave.CambiarDireccion(Sprite.EXPLOTANDO);
        nave.SetActivo(false);
    }
}
