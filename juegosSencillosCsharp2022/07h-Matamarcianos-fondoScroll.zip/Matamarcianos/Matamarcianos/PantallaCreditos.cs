﻿class PantallaCreditos
{
    public void Lanzar()
    {
        bool terminado = false;
        Fuente tipoDeLetra, tipoDeLetraGrande;
        tipoDeLetra = new Fuente("datos\\joystix.ttf", 18);
        tipoDeLetraGrande = new Fuente("datos\\joystix.ttf", 48);

        do
        {
            Hardware.BorrarPantallaOculta();

            Hardware.EscribirTextoOculta("MATAMARCIANOS",
                400, 150, // Coordenadas
                200, 200, 200, // Colores
                tipoDeLetraGrande);
            Hardware.EscribirTextoOculta("Por Nacho, 2022",
                500, 350, // Coordenadas
                180, 180, 180, // Colores
                tipoDeLetra);
            Hardware.EscribirTextoOculta("Pulsa V para volver",
                500, 400, // Coordenadas
                160, 160, 160, // Colores
                tipoDeLetra);

            Hardware.VisualizarOculta();
            Hardware.Pausa(20);

            if (Hardware.TeclaPulsada(Hardware.TECLA_V))
            {
                terminado = true;
            }
        }
        while (!terminado);
    }
}
